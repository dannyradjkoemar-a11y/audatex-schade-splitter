import { 
  AnalyseResultaat, 
  CalculatieRegel, 
  SectieType, 
  BewerkingType, 
  AudatexEindcalculatieData,
  SpuitMateriaalSplitPost,
  TekstzoneItem
} from '../types/audatex';
import { formatDutchPlate } from './rdwService';

/**
 * Categoriseert een calculatiepositie/onderdeel naar 'voorzijde', 'achterzijde' of 'overig'
 * conform Solera Audatex standaarden (positiecodes en vaktermen).
 */
export function categorizeSector(description: string, code?: string): SectieType {
  const lower = (description || '').toLowerCase();

  // 1. Expliciete tekstuele indicatoren
  // Voorzijde
  if (
    lower.includes('voorbumper') || 
    lower.includes('bumper v') || 
    lower.includes('motorkap') || 
    lower.includes('klep v') ||
    lower.includes('koplamp') || 
    lower.includes('radiateur') || 
    lower.includes('koeler') || 
    lower.includes('condensor') ||
    lower.includes('grille') || 
    lower.includes('voorscherm') || 
    lower.includes('spatscherm v') || 
    lower.includes('kentekenplaat v') || 
    lower.includes('kenteken-verst v') || 
    lower.includes('schokdemper v') || 
    lower.includes('steun bumper v') || 
    lower.includes('frontpaneel') ||
    lower.includes('voorpaneel') ||
    lower.includes('voorruit') ||
    lower.includes('radar v')
  ) {
    return 'voorzijde';
  }

  // Achterzijde
  if (
    lower.includes('achterbumper') || 
    lower.includes('bumper a') || 
    lower.includes('achterklep') || 
    lower.includes('kofferdeksel') || 
    lower.includes('achterlicht') || 
    lower.includes('achterscherm') || 
    lower.includes('achterzijpaneel') ||
    lower.includes('spatscherm a') || 
    lower.includes('achterpaneel') ||
    lower.includes('achtertussenpaneel') ||
    lower.includes('kentekenplaat a') || 
    lower.includes('trekhaak') || 
    lower.includes('diffusor') || 
    lower.includes('diffuser') || 
    lower.includes('houder bumper a') || 
    lower.includes('steun bumper a') || 
    lower.includes('anti-roest') ||
    lower.includes('achterruit') ||
    lower.includes('kofferruimte')
  ) {
    return 'achterzijde';
  }

  // Overig (diagnose, algemeen, zijkanten / portieren / dorpels tenzij expliciet V/A)
  if (
    lower.includes('foutgeheugen') || 
    lower.includes('diagnose') || 
    lower.includes('proefrit') || 
    lower.includes('wassen') ||
    lower.includes('airco afvullen') ||
    lower.includes('uitlijnen') ||
    lower.includes('tijdtoeslag voor een hoofdbewerking')
  ) {
    return 'overig';
  }

  // 2. Audatex Positiecode logica
  if (code) {
    const c = code.trim();
    // Front codes in Audatex: 01xx, 02xx, 03xx, 04xx (motorkap), 07xx (voorscherm), 51 11 (BMW front), 61 67, 63 10
    if (
      c.startsWith('01') || 
      c.startsWith('02') || 
      c.startsWith('03') || 
      c.startsWith('04') ||
      c.startsWith('07') ||
      c.startsWith('51 11') || 
      c.startsWith('61 67') || 
      c.startsWith('63 10')
    ) {
      return 'voorzijde';
    }

    // Rear codes in Audatex: 11xx, 12xx, 24xx (achterscherm), 25xx, 26xx, 27xx, 28xx, 29xx, 51 12 (BMW rear), 63 21, 51 99
    if (
      c.startsWith('11') || 
      c.startsWith('12') || 
      c.startsWith('24') ||
      c.startsWith('25') || 
      c.startsWith('26') || 
      c.startsWith('27') ||
      c.startsWith('28') ||
      c.startsWith('29') || 
      c.startsWith('51 12') || 
      c.startsWith('63 21') || 
      c.startsWith('51 99')
    ) {
      return 'achterzijde';
    }

    // Specific PDC sensor pos numbers in Audatex
    if (c.includes('66 20 610')) return 'voorzijde';
    if (c.includes('66 20 603')) return 'achterzijde';
    if (c.startsWith('98')) return 'overig';
  }

  return 'overig';
}

/**
 * Bepaalt of een onderdeel/spuitregel metaal of kunststof betreft conform Solera AZT indeling
 */
export function detectMateriaalSoort(description: string, spuitFase?: string): 'metaal' | 'kunststof' {
  const upper = (description || '').toUpperCase();
  const fase = (spuitFase || '').toUpperCase();

  // SV1..SV4 zijn per definitie kunststof bewerkingscodes in AZT (TZ 51)
  if (fase.startsWith('SV1') || fase.startsWith('SV2') || fase.startsWith('SV3') || fase.startsWith('SV4')) {
    return 'kunststof';
  }

  if (
    upper.includes('BUMPER') ||
    upper.includes('GRILLE') ||
    upper.includes('SPOILER') ||
    upper.includes('SPIEGEL') ||
    upper.includes('STOOTLIJST') ||
    upper.includes('SIERLIJST') ||
    upper.includes('KUNSTSTOF') ||
    upper.includes('DIFFUS') ||
    upper.includes('DORPELVERBR')
  ) {
    return 'kunststof';
  }

  return 'metaal';
}

/**
 * Hulpfunctie voor het parsen van Nederlandse/Audatex getalnotaties (bv. "2 095.68", "1.234,42", "33.60-")
 */
function parseDutchNumber(input?: string): number {
  if (!input) return 0;
  let clean = input.replace(/\s+/g, '').replace(/\*/g, '').trim();
  const isNegative = clean.endsWith('-') || clean.startsWith('-');
  clean = clean.replace(/-/g, '');
  let val = 0;
  if (clean.includes(',') && clean.includes('.')) {
    // 1.234,56
    val = parseFloat(clean.replace(/\./g, '').replace(',', '.')) || 0;
  } else if (clean.includes(',')) {
    val = parseFloat(clean.replace(',', '.')) || 0;
  } else {
    val = parseFloat(clean) || 0;
  }
  return isNegative ? -val : val;
}

/**
 * Volledige Solera Audatex Parser voor officiële Audatex calculatierapporten en teksten
 */
export function parseAudatexReport(rawText: string): AnalyseResultaat | null {
  if (!rawText || rawText.trim().length < 20) return null;

  // Herkenningscheck: bevat de tekst Audatex-specifieke secties of tabellen?
  const isAudatexStructure =
    /S\s*P\s*U\s*I\s*T\s*W\s*E\s*R\s*K/i.test(rawText) ||
    /E\s*I\s*N\s*D\s*C\s*A\s*L\s*C\s*U\s*L\s*A\s*T\s*I\s*E/i.test(rawText) ||
    /A\s*R\s*B\s*E\s*I\s*D\s*S\s*L\s*O\s*O\s*N\s+TIJDBASIS/i.test(rawText) ||
    /O\s*N\s*D\s*E\s*R\s*D\s*E\s*L\s*E\s*N/i.test(rawText) ||
    /SYSTEEM\s+(?:AZT|AUDATEX)/i.test(rawText);

  if (!isAudatexStructure) {
    return null;
  }

  // 1. Voertuig & Dossier Metadata
  let kenteken = 'ONBEKEND';
  const kentMatch = rawText.match(/KENT(?:EKEN)?\.?\s*[:\s]+([0-9A-Z-]{5,10})/i) || 
                    rawText.match(/\b([0-9A-Z]{1,3}-[0-9A-Z]{1,3}-[0-9A-Z]{1,3})\b/i);
  if (kentMatch) {
    kenteken = formatDutchPlate(kentMatch[1].trim());
  }

  let merk = '';
  let model = '';
  // Format op controleblad: "MERK        BMW                   5-SERIE (E60/E61)     520I"
  const controleMerkMatch = rawText.match(/^MERK\s+([A-Z0-9-]+)\s{2,}(.+)$/mi);
  if (controleMerkMatch) {
    merk = controleMerkMatch[1].trim();
    model = controleMerkMatch[2].replace(/\s{2,}/g, ' / ').trim();
  } else {
    const merkMatch = rawText.match(/MERK\s*[:\s]+([A-Z0-9-]+)(?:\s{2,}|\n|$)/i);
    if (merkMatch) merk = merkMatch[1].trim();
    const modelMatch = rawText.match(/MODEL\/TYPE\s*[:\s]+([^\n]+)/i);
    if (modelMatch) model = modelMatch[1].replace(/\s{2,}/g, ' ').trim();
  }
  const merkModel = [merk, model].filter(Boolean).join(' ').trim() || 'Onbekend voertuig (via Audatex)';

  let calculatienummer = 'ADX-' + Math.floor(100000 + Math.random() * 900000);
  let datumCalculatie = new Date().toLocaleDateString('nl-NL');
  const calcNrMatch = rawText.match(/S\s*C\s*H\s*A\s*D\s*E\s*-\s*C\s*A\s*L\s*C\s*U\s*L\s*A\s*T\s*I\s*E\s+NR\s+([0-9]+)\s+([0-9.]+)/i) ||
                      rawText.match(/CALCULATIE\s+NR\s+([0-9]+)\s+([0-9.]+)/i);
  if (calcNrMatch) {
    calculatienummer = calcNrMatch[1].trim();
    datumCalculatie = calcNrMatch[2].trim();
  }

  let dossiernummer = calculatienummer;
  const schadeNrMatch = rawText.match(/SCHADE(?:NUMMER|-NR)\s*[:\s]+([0-9A-Z-]+)/i);
  if (schadeNrMatch) dossiernummer = schadeNrMatch[1].trim();

  let datumSchade = datumCalculatie;
  const datumSchadeMatch = rawText.match(/SCHADE-DATUM\s*[:\s]+([0-9.]+)/i);
  if (datumSchadeMatch) datumSchade = datumSchadeMatch[1].trim();

  let chassisnummer = 'N/A';
  const chassisMatch = rawText.match(/(?:CHASSISNUMMER|VTG\.-ID\.-NR\.)\s*[:\s]*([A-Z0-9]{8,17})/i);
  if (chassisMatch) chassisnummer = chassisMatch[1].trim();

  let expertHersteller = 'Solera Audatex Schadehersteller';
  const reparateurMatch = rawText.match(/REPARATEUR\s*[:\s]+([^\n]+)/i);
  if (reparateurMatch) expertHersteller = reparateurMatch[1].trim();

  let laksoort = 'Metallic / 2-Laags (AZT)';
  const lakMatch = rawText.match(/AANDUIDING\s+-\s+([^\n]+)/i);
  if (lakMatch) {
    let lakRaw = lakMatch[1].replace(/\s+AE\s*$/, '').trim();
    // Check op een vervolgregel voor Nat in Nat / Drogen/Schuren / Blanke lak hard
    const lakIdx = rawText.indexOf(lakMatch[0]);
    const nextLineBlock = rawText.slice(lakIdx + lakMatch[0].length, lakIdx + lakMatch[0].length + 120);
    const subLak = nextLineBlock.match(/^\r?\n\s+-\s+([^\r\n]+)/);
    if (subLak) {
      lakRaw += ` (${subLak[1].trim()})`;
    }
    laksoort = lakRaw;
  }

  // US-codes uitlezen
  const usCodes: string[] = [];
  const usBlockMatch = rawText.match(/-\s*BASIS-SPECIFICATIES\s*:\s*([\s\S]*?)(?:\r?\n\r?\n|ONDERDELEN|TARIEF)/i) ||
                       rawText.match(/-\s*US CODES AUDAID\s*:\s*([\s\S]*?)(?:-|ONDERDELEN)/i);
  if (usBlockMatch) {
    const tokens = usBlockMatch[1].match(/\b[A-Z][0-9]\b/g);
    if (tokens) {
      tokens.forEach(t => { if (!usCodes.includes(t)) usCodes.push(t); });
    }
  }

  // Actieve Tekstzone-codes uitlezen
  const actieveTekstzones: TekstzoneItem[] = [];
  const tzBlockMatch = rawText.match(/-\s*ACTIEVE CODES\s*:\s*([\s\S]*?)(?:-\s*ONGELDIGE CODES|ONDERDELEN\r?\n|\r?\n\r?\n)/i);
  if (tzBlockMatch) {
    const pairs = tzBlockMatch[1].matchAll(/\b([0-9]{2,3})\s+([0-9.,]+-?)/g);
    for (const p of pairs) {
      actieveTekstzones.push({ code: p[1], waarde: p[2] });
    }
  }

  // 2. Tarieven & Factoren uitlezen
  let tariefPerAE = 0;
  const tariefMatch = rawText.match(/TARIEF\/KL[123]\s*=\s*([0-9.,]+)\s*EURO\/AE/i) || 
                      rawText.match(/SPUITERIJ\s*:\s*([0-9.,]+)\s*EURO\/AE/i) ||
                      rawText.match(/TARIEF\s+([0-9.,]+)\s*EURO\/AE/i) ||
                      rawText.match(/X\s+([0-9.,]+)\s*EURO\/AE/i);
  if (tariefMatch) {
    tariefPerAE = parseDutchNumber(tariefMatch[1]);
  }
  if (!tariefPerAE || tariefPerAE <= 0) tariefPerAE = 8.81;
  const uurtarief = Math.round(tariefPerAE * 10 * 100) / 100;

  let milieuTariefPerAE = 0;
  const milieuTariefMatch = rawText.match(/TOESLAG\s+WP\+SP[^\n]+?X\s+([0-9.,]+)\s*EURO\/AE/i);
  if (milieuTariefMatch) {
    milieuTariefPerAE = parseDutchNumber(milieuTariefMatch[1]);
  } else {
    const tz123 = actieveTekstzones.find(t => t.code === '123');
    if (tz123) milieuTariefPerAE = parseDutchNumber(tz123.waarde);
  }

  let onderdelenKortingPerc = 0;
  const kortingMatch = rawText.match(/KORTING\s+([0-9.,]+)%/i);
  if (kortingMatch) {
    onderdelenKortingPerc = parseDutchNumber(kortingMatch[1]);
  } else {
    const tz20 = actieveTekstzones.find(t => t.code === '20');
    if (tz20) onderdelenKortingPerc = parseDutchNumber(tz20.waarde);
  }

  let kleinMateriaalPerc = 2.0;
  const kleinMatMatch = rawText.match(/KLEINMATERIAAL\s*\(\s*([0-9.,]+)%\)/i);
  if (kleinMatMatch) {
    kleinMateriaalPerc = parseDutchNumber(kleinMatMatch[1]);
  }

  // Materiaalindex (TZ 51)
  let materiaalIndexPerc = 100;
  const matIndexMatch = rawText.match(/MATERIAALINDEX\s+([0-9.,]+)\s*%/i);
  if (matIndexMatch) {
    materiaalIndexPerc = parseDutchNumber(matIndexMatch[1]);
  } else {
    const tz51 = actieveTekstzones.find(t => t.code === '51');
    if (tz51) materiaalIndexPerc = parseDutchNumber(tz51.waarde);
  }

  // 3. Gedetailleerde SPUITWERK sectie uitlezen
  let spuitTijdPaneelAE = 0;
  let spuitVoorbereidingMetaalAE = 0;
  let spuitVoorbereidingKunststofAE = 0;
  let spuitVoorbereidingMeerlagenAE = 0;
  let spuitLoonTotaalAE = 0;
  let spuitLoonBedragUitTabel = 0;

  let materiaalConstanteMetaal = 0;
  let materiaalConstanteKunststof = 0;
  let materiaalConstanteMeerlagen = 0;
  const spuitMateriaalPosten: SpuitMateriaalSplitPost[] = [];

  const paintHeaderMatch = rawText.match(/S\s*P\s*U\s*I\s*T\s*W\s*E\s*R\s*K\s+SYSTEEM\s+AZT/i);
  const paintHeaderIndex = paintHeaderMatch ? (paintHeaderMatch.index ?? -1) : -1;
  const paintBlock = paintHeaderIndex !== -1
    ? rawText.slice(paintHeaderIndex, rawText.indexOf('E I N D C A L C U L A T I E', paintHeaderIndex) !== -1
        ? rawText.indexOf('E I N D C A L C U L A T I E', paintHeaderIndex)
        : paintHeaderIndex + 4000)
    : '';

  if (paintBlock) {
    const spLines = paintBlock.split(/\r?\n/);
    let inMateriaalKosten = false;

    for (const spLine of spLines) {
      if (/SPUIT-MATERIAALKOSTEN/i.test(spLine)) {
        inMateriaalKosten = true;
        continue;
      }

      if (!inMateriaalKosten) {
        const spuitTijdM = spLine.match(/^\s*SPUITTIJD\s+([0-9.,]+)/i);
        if (spuitTijdM) { spuitTijdPaneelAE = parseDutchNumber(spuitTijdM[1]); continue; }

        const vbMetaalM = spLine.match(/VOORBER(?:EIDING)?[^0-9]*METAAL\s+([0-9.,]+)/i);
        if (vbMetaalM) { spuitVoorbereidingMetaalAE = parseDutchNumber(vbMetaalM[1]); continue; }

        const vbKunstM = spLine.match(/VOORBER(?:EIDING)?[^0-9]*KUNSTSTOF\s+([0-9.,]+)/i);
        if (vbKunstM) { spuitVoorbereidingKunststofAE = parseDutchNumber(vbKunstM[1]); continue; }

        const vbMeerM = spLine.match(/VOORBER(?:EIDING)?[^0-9]*MEERLAGEN\s+([0-9.,]+)/i);
        if (vbMeerM) { spuitVoorbereidingMeerlagenAE = parseDutchNumber(vbMeerM[1]); continue; }

        const totSpuitM = spLine.match(/TOTAAL\s+10\s*AE\/UUR\s*:\s*([0-9.,]+)\s+([0-9.,]+)/i);
        if (totSpuitM) {
          spuitLoonTotaalAE = parseDutchNumber(totSpuitM[1]);
          spuitLoonBedragUitTabel = parseDutchNumber(totSpuitM[2]);
          continue;
        }
      } else {
        const matMetaalM = spLine.match(/(?:HOOFDMATERIAALCONST\.?|MATERIAAL-?CONSTANTE)[^0-9]*METAAL\s+([0-9.,]+)/i);
        if (matMetaalM) { materiaalConstanteMetaal = parseDutchNumber(matMetaalM[1]); continue; }

        const matKunstM = spLine.match(/(?:GECOMB\.?\s*)?MATERIAAL-?CONSTANTE[^0-9]*KUNSTSTOF\s+([0-9.,]+)/i);
        if (matKunstM) { materiaalConstanteKunststof = parseDutchNumber(matKunstM[1]); continue; }

        const matMeerM = spLine.match(/MATERIAAL-?CONSTANTE[^0-9]*MEERLAGEN\s+([0-9.,]+)/i);
        if (matMeerM) { materiaalConstanteMeerlagen = parseDutchNumber(matMeerM[1]); continue; }

        const postM = spLine.match(/^\s+(SPUITEN\s+NA\s+VERN\.?|SPUITEN\s+NA\s+HERST\.?|DEKLAAG\s+SPUITEN|UITSPUITEN|SPOT-?REPAIR)[^\n]*?\s+([0-9.,]+)\s*$/i);
        if (postM) {
          const omsch = postM[1].trim();
          const upperO = omsch.toUpperCase();
          const bedrag = parseDutchNumber(postM[2]);
          const cat: SpuitMateriaalSplitPost['categorie'] =
            upperO.includes('VERN') ? 'vern' :
            upperO.includes('HERST') ? 'herst' :
            upperO.includes('UITSPUIT') ? 'uitspuiten' :
            upperO.includes('DEKLAAG') ? 'deklaag' : 'overig';
          spuitMateriaalPosten.push({ categorie: cat, omschrijving: omsch, bedragBruto: bedrag });
        }
      }
    }
  }

  const materiaalconstante =
    (materiaalConstanteMetaal + materiaalConstanteKunststof + materiaalConstanteMeerlagen) > 0
      ? Math.round((materiaalConstanteMetaal + materiaalConstanteKunststof + materiaalConstanteMeerlagen) * (materiaalIndexPerc / 100) * 100) / 100
      : 33.60;

  // 4. Officiële Audatex Eindcalculatie Samenvatting
  const parseAmount = (re: RegExp) => {
    const m = rawText.match(re);
    return m ? Math.abs(parseDutchNumber(m[1])) : 0;
  };

  const onderdelenNetto = parseAmount(/TOTAALBEDRAG\s+O\s*N\s*D\s*E\s*R\s*D\s*E\s*L\s*E\s*N[^\d\n]*([0-9\s.,]+)/i);
  const arbeidNetto = parseAmount(/TOTAALBEDRAG\s+A\s*R\s*B\s*E\s*I\s*D\s*S\s*L\s*O\s*O\s*N[^\d\n]*([0-9\s.,]+)/i);
  const bijkomendNetto = parseAmount(/TOTAALBEDRAG\s+B\s*I\s*J\s*K\s*O\s*M\s*E\s*N\s*D\s*E\s*K\s*O\s*S\s*T\s*E\s*N[^\d\n]*([0-9\s.,]+)/i);
  const spuitwerkNetto = parseAmount(/TOTAALBEDRAG\s+S\s*P\s*U\s*I\s*T\s*W\s*E\s*R\s*K[^\d\n]*([0-9\s.,]+)/i);
  const milieuNetto = parseAmount(/TOTAALBEDRAG\s+M\s*I\s*L\s*I\s*E\s*U\s*T\s*O\s*E\s*S\s*L\s*A\s*G[^\d\n]*([0-9\s.,]+)/i);
  const totaalExclBtw = parseAmount(/R\s*E\s*P\s*A\s*R\s*A\s*T\s*I\s*E\s*K\s*O\s*S\s*T\s*E\s*N\s+EXCL\.\s*BTW[^\d\n]*([0-9\s.,]+)/i);
  const btwMatch = rawText.match(/BTW\s+([0-9.,]+)\s*%\s+([0-9\s.,]+)/i);
  const btwPercentage = btwMatch ? parseDutchNumber(btwMatch[1]) : 21.0;
  const btwBedrag = btwMatch ? parseDutchNumber(btwMatch[2]) : 0;
  const totaalInclBtw = parseAmount(/R\s*E\s*P\s*A\s*R\s*A\s*T\s*I\s*E\s*K\s*O\s*S\s*T\s*E\s*N\s+INCL\.\s*BTW[^\d\n]*([0-9\s.,]+)/i);

  const aftrekSpuitbedragTZ143 = parseAmount(/AFTREK\s+SPUITBEDRAG\s+([0-9\s.,]+-?)/i);
  const aftrekEersteSchadeTZ95 = parseAmount(/AFTREK\s+EERSTE\s+SCHADE\s+([0-9\s.,]+-?)/i);

  const eindCalcSpuitArbeid = parseAmount(/ARBEIDSLOON\s+([0-9\s.,]+)\r?\n\s+SPUIT-MATERIAALKOSTEN/i) || spuitLoonBedragUitTabel;
  const eindCalcSpuitMateriaal = parseAmount(/SPUIT-MATERIAALKOSTEN\s+([0-9][0-9\s.,]+)\s*$/m);

  const heeftAudatexSamenvatting = totaalExclBtw > 0 && (onderdelenNetto > 0 || arbeidNetto > 0 || spuitwerkNetto > 0);

  const audatexEindcalculatie: AudatexEindcalculatieData | undefined = heeftAudatexSamenvatting ? {
    onderdelenNetto,
    arbeidNetto,
    bijkomendNetto,
    spuitwerkNetto,
    milieuNetto,
    totaalExclBtw,
    btwBedrag,
    totaalInclBtw,
    onderdelenBruto: parseAmount(/O\s*N\s*D\s*E\s*R\s*D\s*E\s*L\s*E\s*N\s+([0-9\s.,]+)\r?\n\s+(?:KORTING|KLEINMATERIAAL)/i),
    onderdelenKorting: parseAmount(/KORTING[^\n]+?([0-9\s.,]+-?)\s*$/m),
    kleinMateriaal: parseAmount(/KLEINMATERIAAL[^\n]*?([0-9.,]+)\s*$/m),
    spuitarbeidNetto: eindCalcSpuitArbeid,
    spuitmateriaalNetto: eindCalcSpuitMateriaal,
    spuitTijdPaneelAE: spuitTijdPaneelAE || undefined,
    spuitVoorbereidingMetaalAE: spuitVoorbereidingMetaalAE || undefined,
    spuitVoorbereidingKunststofAE: spuitVoorbereidingKunststofAE || undefined,
    spuitVoorbereidingMeerlagenAE: spuitVoorbereidingMeerlagenAE || undefined,
    spuitLoonTotaalAE: spuitLoonTotaalAE || undefined,
    materiaalConstanteMetaal: materiaalConstanteMetaal || undefined,
    materiaalConstanteKunststof: materiaalConstanteKunststof || undefined,
    materiaalConstanteMeerlagen: materiaalConstanteMeerlagen || undefined,
    materiaalIndexPerc,
    aftrekSpuitbedragTZ143: aftrekSpuitbedragTZ143 || undefined,
    aftrekEersteSchadeTZ95: aftrekEersteSchadeTZ95 || undefined,
    spuitMateriaalPosten: spuitMateriaalPosten.length > 0 ? spuitMateriaalPosten : undefined
  } : undefined;

  // 5. Calculatieregels uitlezen
  const regels: CalculatieRegel[] = [];
  let regelsIndex = 1;

  // TABEL 1: O N D E R D E L E N
  const partsHeaderIndex = rawText.indexOf('PRIJSLIJST VAN') !== -1
    ? rawText.indexOf('PRIJSLIJST VAN')
    : rawText.search(/O\s*N\s*D\s*E\s*R\s*D\s*E\s*L\s*E\s*N/i);
  if (partsHeaderIndex !== -1) {
    const nextSectionIndex = rawText.search(/A\s*R\s*B\s*E\s*I\s*D\s*S\s*L\s*O\s*O\s*N/i);
    const endPartsIdx = nextSectionIndex > partsHeaderIndex ? nextSectionIndex : partsHeaderIndex + 4000;
    const partsBlock = rawText.slice(partsHeaderIndex, endPartsIdx);
    const pLines = partsBlock.split(/\r?\n/);

    for (const pLine of pLines) {
      const m = pLine.match(/^\s*([0-9]{4})\s+(.+?)\s+([0-9]+[.,][0-9]{2})\*?\s*$/);
      if (m) {
        const code = m[1];
        const rest = m[2].trim();
        const prijs = parseDutchNumber(m[3]);

        let oeNr = '';
        let benaming = rest;
        const oeMatch = rest.match(/\s+([A-Z0-9]{2,}\s+[A-Z0-9\s]+)$/);
        if (oeMatch && /[0-9]/.test(oeMatch[1]) && oeMatch[1].trim().length >= 8) {
          oeNr = oeMatch[1].trim();
          benaming = rest.slice(0, rest.length - oeMatch[0].length).trim();
        }

        const sectie = categorizeSector(benaming, code);

        regels.push({
          id: `regel-ond-${regelsIndex++}`,
          code,
          omschrijving: benaming,
          sectie,
          bewerking: 'VERN',
          itemType: 'onderdeel',
          onderdeelPrijs: prijs,
          arbeidPlaatwerkAE: 0,
          arbeidDemontageAE: 0,
          spuittijdAE: 0,
          arbeidPlaatwerkUren: 0,
          arbeidDemontageUren: 0,
          spuittijdUren: 0,
          artikelnummer: oeNr || undefined
        });
      }
    }
  }

  // TABEL 2: A R B E I D S L O O N
  const laborHeaderMatch = rawText.match(/A\s*R\s*B\s*E\s*I\s*D\s*S\s*L\s*O\s*O\s*N\s+TIJDBASIS/i);
  if (laborHeaderMatch && laborHeaderMatch.index !== undefined) {
    const laborHeaderIndex = laborHeaderMatch.index;
    const paintIdx = paintHeaderIndex > laborHeaderIndex ? paintHeaderIndex : rawText.length;
    const laborBlock = rawText.slice(laborHeaderIndex, Math.min(paintIdx, laborHeaderIndex + 6000));
    const lLines = laborBlock.split(/\r?\n/);

    let currentLaborItem: CalculatieRegel | null = null;

    for (const lLine of lLines) {
      if (lLine.includes('SPECIFICATIE HERSTELWERKZAAMHEDEN') || lLine.includes('TARIEF/KL')) continue;

      const endMatch = lLine.match(/\s+([12345])\s+([0-9]+(?:[.,][0-9]+)?)\*?\s+([0-9]+[.,][0-9]{2})\s*$/);
      if (endMatch) {
        if (currentLaborItem) {
          regels.push(currentLaborItem);
        }

        const beforeEnd = lLine.slice(0, lLine.length - endMatch[0].length).trim();
        const firstSpace = beforeEnd.search(/\s{2,}/);
        let posNr = '';
        let omschrijving = '';

        if (firstSpace !== -1) {
          posNr = beforeEnd.slice(0, firstSpace).trim();
          omschrijving = beforeEnd.slice(firstSpace).trim();
        } else {
          const mPos = beforeEnd.match(/^([0-9A-Z\(\)]+(?:\s+[0-9A-Z\(\)]+)?)\s+(.+)$/);
          if (mPos) {
            posNr = mPos[1].trim();
            omschrijving = mPos[2].trim();
          } else {
            omschrijving = beforeEnd;
          }
        }

        const kl = parseInt(endMatch[1], 10);
        const ae = parseDutchNumber(endMatch[2]);
        const bedrag = parseDutchNumber(endMatch[3]);

        const sectie = categorizeSector(omschrijving, posNr);

        let bewerking: BewerkingType = 'DIV';
        const upper = omschrijving.toUpperCase();
        if (upper.includes('HERSTELLEN') || upper.includes('RICHTEN') || upper.includes('PLAATWERK')) {
          bewerking = 'HERST';
        } else if (upper.includes('UIT-/INBOUWEN') || upper.includes('UIT-/INB') || upper.includes('D+M') || upper.includes('DE/MONTEREN')) {
          bewerking = 'DM';
        } else if (upper.includes('VERNIEUWEN') || upper.includes('VERVANGEN')) {
          bewerking = 'VERN';
        }

        currentLaborItem = {
          id: `regel-arb-${regelsIndex++}`,
          code: posNr,
          omschrijving,
          sectie,
          bewerking,
          itemType: 'arbeid',
          onderdeelPrijs: 0,
          arbeidPlaatwerkAE: bewerking === 'HERST' ? ae : 0,
          arbeidDemontageAE: bewerking !== 'HERST' ? ae : 0,
          spuittijdAE: 0,
          arbeidPlaatwerkUren: bewerking === 'HERST' ? ae / 10 : 0,
          arbeidDemontageUren: bewerking !== 'HERST' ? ae / 10 : 0,
          spuittijdUren: 0,
          arbeidsloonBedrag: bedrag,
          klasse: kl
        };
      } else if (currentLaborItem && (lLine.match(/^\s{5,}/) || lLine.trim().startsWith('('))) {
        const trimmed = lLine.trim();
        if (trimmed && !trimmed.includes('SYSTEEM AUDATEX') && !trimmed.includes('SCHADENET') && !trimmed.includes('S C H A D E')) {
          currentLaborItem.omschrijving += ' ' + trimmed;
        }
      }
    }
    if (currentLaborItem) {
      regels.push(currentLaborItem);
    }
  }

  // TABEL 3: S P U I T W E R K
  if (paintBlock) {
    const spLines = paintBlock.split(/\r?\n/);

    for (const spLine of spLines) {
      if (spLine.includes('SPUITTIJD') || spLine.includes('VOORBER') || spLine.includes('TOTAAL') || spLine.includes('SPUITLOON') || spLine.includes('SPUIT-MATERIAALKOSTEN')) {
        continue;
      }

      // Ondersteunt zowel "0283 BUMPER V SPUITEN NA VERN. SV1 14", "0471 MOTORKAP SPUITEN NA VERN. 13.0", "0471 TIJDTOESLAG KRASVASTE LAK 5*", als "1481 PORTIER V L UITSPUITEN 8"
      const m = spLine.match(/^\s*([0-9]{4})\s+(.+?)\s+([0-9]+(?:[.,][0-9]+)?)\*?\s*$/);
      if (m) {
        const code = m[1];
        const omschrijving = m[2].trim().replace(/\s{2,}/g, ' — ');
        const spuitAE = parseDutchNumber(m[3]);
        const upperOmsch = omschrijving.toUpperCase();

        // Extract spuitfase
        let spuitFase = '';
        const faseMatch = upperOmsch.match(/\b(SV1|SV2|SV3|SV4|SH1|SH|SV|LB|LS|NL)\b/);
        if (faseMatch) {
          spuitFase = faseMatch[1];
        } else if (upperOmsch.includes('KRASVASTE LAK')) {
          spuitFase = 'NL';
        } else if (upperOmsch.includes('UITSPUITEN')) {
          spuitFase = 'LB';
        } else if (upperOmsch.includes('DEKLAAG')) {
          spuitFase = 'S';
        } else if (upperOmsch.includes('SPOT')) {
          spuitFase = 'LS';
        } else if (upperOmsch.includes('HERST')) {
          spuitFase = 'SH';
        } else if (upperOmsch.includes('VERN')) {
          spuitFase = 'SV';
        }

        // Voor "TIJDTOESLAG KRASVASTE LAK" erven we de sectie uit een voorgaande spuitregel met dezelfde code
        let sectie = categorizeSector(omschrijving, code);
        if (upperOmsch.includes('TIJDTOESLAG') && sectie === 'overig') {
          const prevSameCode = regels.find(r => r.code === code && r.itemType === 'spuitwerk');
          if (prevSameCode) sectie = prevSameCode.sectie;
        }

        const bewerking: BewerkingType =
          upperOmsch.includes('UITSPUITEN') ? 'UITSP' :
          upperOmsch.includes('SPOT') ? 'LS' :
          upperOmsch.includes('HERST') ? 'SPH' : 'SP';

        const materiaalSoort = detectMateriaalSoort(omschrijving, spuitFase);

        regels.push({
          id: `regel-spuit-${regelsIndex++}`,
          code,
          omschrijving: `Spuiten: ${omschrijving}`,
          sectie,
          bewerking,
          itemType: 'spuitwerk',
          spuitFase,
          materiaalSoort,
          onderdeelPrijs: 0,
          arbeidPlaatwerkAE: 0,
          arbeidDemontageAE: 0,
          spuittijdAE: spuitAE,
          arbeidPlaatwerkUren: 0,
          arbeidDemontageUren: 0,
          spuittijdUren: spuitAE / 10,
          arbeidsloonBedrag: Math.round(spuitAE * tariefPerAE * 100) / 100
        });
      }
    }
  }

  // BIJKOMENDE KOSTEN (TZ 60-74: Anti-roestbehandeling, Bescherming holle ruimte, Uitlijnen, Transport, etc.)
  const bijkomendIdx = rawText.search(/^\s*B\s*I\s*J\s*K\s*O\s*M\s*E\s*N\s*D\s*E\s+K\s*O\s*S\s*T\s*E\s*N\s*$/im);
  let bijkomendeOmschrijvingen: string[] = [];
  if (bijkomendIdx !== -1) {
    const endBijk = rawText.indexOf('TOTAALBEDRAG', bijkomendIdx);
    const bijkBlock = rawText.slice(bijkomendIdx, endBijk !== -1 ? endBijk : bijkomendIdx + 500);
    const bLines = bijkBlock.split(/\r?\n/);
    for (const bLine of bLines) {
      const bm = bLine.match(/^\s+([A-Z][A-Z0-9\s\-\/]+?)\s+([0-9]+[.,][0-9]{2})\s*$/i);
      if (bm && !/BIJKOMENDE\s+KOSTEN/i.test(bm[1])) {
        const oms = bm[1].trim();
        const bedrag = parseDutchNumber(bm[2]);
        bijkomendeOmschrijvingen.push(oms);
        const sectie = categorizeSector(oms);
        regels.push({
          id: `regel-bijk-${regelsIndex++}`,
          code: oms.toUpperCase().includes('ROEST') ? 'TZ 70' : oms.toUpperCase().includes('UITLIJN') ? 'TZ 74' : 'TZ 60+',
          omschrijving: `${oms} (Bijkomende kosten)`,
          sectie: sectie === 'overig' && oms.toUpperCase().includes('ROEST') ? 'achterzijde' : sectie,
          bewerking: 'DIV',
          itemType: 'bijkomend',
          onderdeelPrijs: bedrag,
          arbeidPlaatwerkAE: 0,
          arbeidDemontageAE: 0,
          spuittijdAE: 0,
          arbeidPlaatwerkUren: 0,
          arbeidDemontageUren: 0,
          spuittijdUren: 0
        });
      }
    }
  }

  // Fallback indien geen enkele regel herkend werd
  if (regels.length === 0) {
    return null;
  }

  // 6. Solera Richtlijn Tekstzone 143 / 95 Aanbeveling
  const advies = `Conform Solera AZT-richtlijn voor meerdere schades: De hoofdmateriaalconstante (€ ${materiaalconstante.toFixed(2)}) is toegewezen conform de actieve verdeelmethode. Bij twee separate calculaties die in één spuitgang worden hersteld, voorkomt Tekstzone 143 (-€ ${materiaalconstante.toFixed(2)}) dubbele vergoeding; bij één complete calculatie kan Tekstzone 95 worden ingezet.`;
  const invoerTekst143 = `TZ 143: -${materiaalconstante.toFixed(2)} EUR (Aftrek AZT materiaalconstante gecombineerde spuitgang kenteken ${kenteken})`;

  const spuitMateriaalTotaal = audatexEindcalculatie?.spuitmateriaalNetto || 0;
  const spuitTijdSom = spuitLoonTotaalAE || regels.filter(r => r.itemType === 'spuitwerk').reduce((s, r) => s + (r.spuittijdAE || 0), 0);

  return {
    meta: {
      kenteken,
      merkModel,
      chassisnummer,
      calculatienummer,
      dossiernummer,
      datumCalculatie,
      datumSchade,
      expertHersteller,
      laksoort,
      kleurcode: 'Standaard lak',
      usCodes: usCodes.length > 0 ? usCodes : undefined,
      actieveTekstzones: actieveTekstzones.length > 0 ? actieveTekstzones : undefined
    },
    tarieven: {
      plaatwerktarief: uurtarief,
      demontagetarief: uurtarief,
      spuittarief: uurtarief,
      spuitmateriaaltarief: 49.50,
      materiaalconstante,
      kleinMateriaalPerc,
      milieutoeslag: milieuNetto,
      btwPercentage,
      tariefPerAE,
      milieuTariefPerAE,
      onderdelenKortingPerc,
      bijkomendeKosten: bijkomendNetto,
      bijkomendeKostenOmschrijving: bijkomendeOmschrijvingen.join(', ') || 'Bijkomende kosten',
      spuitmateriaalTotaal: spuitMateriaalTotaal,
      spuittijdTotaalAE: spuitTijdSom
    },
    materiaalconstanteMethode: 'solera_tz143',
    soleraAanbeveling: {
      titel: 'Solera Richtlijn Meerdere Schades (Tekstzone 143 / TZ 95)',
      tekstzone: 'TZ 143',
      advies,
      invoerTekst143
    },
    audatexEindcalculatie,
    regels
  };
}
