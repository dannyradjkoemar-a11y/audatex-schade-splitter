import { 
  CalculatieRegel, 
  Tarieven, 
  SectieTotalen, 
  MateriaalconstanteMethode, 
  SectieType,
  AudatexEindcalculatieData
} from '../types/audatex';

function round(val: number, decimals: number = 2): number {
  const factor = Math.pow(10, decimals);
  return Math.round((val + Number.EPSILON) * factor) / factor;
}

/**
 * Verdeelt een totaalbedrag over secties naar rato van gewichten en zorgt dat de som
 * op de cent nauwkeurig gelijk is aan het totaalbedrag.
 */
function distributeExact(
  total: number,
  weights: [number, number, number]
): [number, number, number] {
  const sumW = weights[0] + weights[1] + weights[2];
  if (total === 0 || sumW <= 0) {
    return [0, 0, 0];
  }

  const shares: [number, number, number] = [0, 0, 0];
  let lastActiveIdx = 0;
  for (let i = 0; i < 3; i++) {
    if (weights[i] > 0) lastActiveIdx = i;
  }

  let running = 0;
  for (let i = 0; i < 3; i++) {
    if (i === lastActiveIdx) {
      shares[i] = round(total - running, 2);
    } else if (weights[i] > 0) {
      shares[i] = round(total * (weights[i] / sumW), 2);
      running = round(running + shares[i], 2);
    }
  }
  return shares;
}

export function berekenSectieTotalen(
  regels: CalculatieRegel[],
  tarieven: Tarieven,
  methode: MateriaalconstanteMethode,
  audatexEindcalculatie?: AudatexEindcalculatieData
): {
  voorzijde: SectieTotalen;
  achterzijde: SectieTotalen;
  overig: SectieTotalen;
  totaal: SectieTotalen;
  soleraInfo: {
    constanteVoor: number;
    constanteAchter: number;
    constanteOverig: number;
    invoerTekst143: string;
    advies: string;
  };
} {
  // Filters per sectie
  const voorRegels = regels.filter(r => r.sectie === 'voorzijde');
  const achterRegels = regels.filter(r => r.sectie === 'achterzijde');
  const overigRegels = regels.filter(r => r.sectie === 'overig');

  const getSpuitAE = (r: CalculatieRegel) =>
    r.spuittijdAE !== undefined ? r.spuittijdAE : Math.round((r.spuittijdUren || 0) * 10);
  const getPlaatAE = (r: CalculatieRegel) =>
    r.arbeidPlaatwerkAE !== undefined ? r.arbeidPlaatwerkAE : Math.round((r.arbeidPlaatwerkUren || 0) * 10);
  const getDemAE = (r: CalculatieRegel) =>
    r.arbeidDemontageAE !== undefined ? r.arbeidDemontageAE : Math.round((r.arbeidDemontageUren || 0) * 10);

  // Spuittijden paneel (in AE: 10 AE = 1 uur)
  const spuitPaneelVoor = voorRegels.reduce((sum, r) => sum + getSpuitAE(r), 0);
  const spuitPaneelAchter = achterRegels.reduce((sum, r) => sum + getSpuitAE(r), 0);
  const spuitPaneelOverig = overigRegels.reduce((sum, r) => sum + getSpuitAE(r), 0);
  const spuitPaneelTotaal = spuitPaneelVoor + spuitPaneelAchter + spuitPaneelOverig;

  // Verdeling materiaalconstante (voor tekstuele adviezen en standaard rekenmethode)
  let constanteVoor = 0;
  let constanteAchter = 0;
  let constanteOverig = 0;
  let advies = '';
  let invoerTekst143 = '';

  const basisConstante = tarieven.materiaalconstante || 33.60;

  switch (methode) {
    case 'solera_tz143':
      constanteVoor = basisConstante;
      constanteAchter = 0;
      constanteOverig = 0;
      advies = `Conform Solera AZT-richtlijn: De hoofdmateriaalconstante (€ ${basisConstante.toFixed(2)}) wordt eenmalig per materiaalsoort toegepast. Bij separate dossiers voorkomt Tekstzone 143 (-€ ${basisConstante.toFixed(2)}) dubbele vergoeding; bij één complete calculatie voorkomt Tekstzone 95 dubbele telling.`;
      invoerTekst143 = `TZ 143: Aftrek spuitbedrag -${basisConstante.toFixed(2)} EUR (Voorkomen dubbele AZT materiaalconstante ivm gecombineerde spuitdoorgang)`;
      break;

    case 'proportioneel_spuittijd':
      if (spuitPaneelTotaal > 0) {
        [constanteVoor, constanteAchter, constanteOverig] = distributeExact(
          basisConstante,
          [spuitPaneelVoor, spuitPaneelAchter, spuitPaneelOverig]
        );
      } else {
        constanteVoor = round(basisConstante / 2, 2);
        constanteAchter = round(basisConstante - constanteVoor, 2);
      }
      advies = `Proportionele verdeling: Materiaalconstante (€ ${basisConstante.toFixed(2)}) is verdeeld op basis van de verhouding in spuittijd (${spuitPaneelTotaal > 0 ? ((spuitPaneelVoor / spuitPaneelTotaal) * 100).toFixed(1) : '50'}% voor vs ${spuitPaneelTotaal > 0 ? ((spuitPaneelAchter / spuitPaneelTotaal) * 100).toFixed(1) : '50'}% achter).`;
      invoerTekst143 = `TZ 143: Correctie materiaalconstante naar rato van spuittijd (Voor: €${constanteVoor.toFixed(2)}, Achter: €${constanteAchter.toFixed(2)})`;
      break;

    case 'fifty_fifty':
      constanteVoor = round(basisConstante / 2, 2);
      constanteAchter = round(basisConstante - constanteVoor, 2);
      advies = `50/50 Gelijkmatige verdeling: Beide hoofddossiers dragen exact de helft (€ ${constanteVoor.toFixed(2)} / € ${constanteAchter.toFixed(2)}) van de materiaalconstante.`;
      invoerTekst143 = `TZ 143: Aftrek 50% materiaalconstante -${constanteAchter.toFixed(2)} EUR ivm gesplitste voor/achterzijde calculatie`;
      break;

    case 'beide_volledig':
      constanteVoor = basisConstante;
      constanteAchter = basisConstante;
      advies = `Let op: Beide secties bevatten de volledige materiaalconstante (€ ${basisConstante.toFixed(2)}). Indien de auto in één spuitgang wordt behandeld, kan een verzekeraar dit aanmerken als dubbele vergoeding (Solera adviseert TZ 143 aftrek).`;
      invoerTekst143 = 'Geen aftrek toegepast (Beide calculaties dragen onafhankelijk de volledige constante).';
      break;
  }

  // =========================================================================
  // 1. DYNAMISCHE BEREKENING O.B.V. OFFICIËLE AUDATEX EINDCALCULATIE
  // =========================================================================
  if (audatexEindcalculatie && audatexEindcalculatie.totaalExclBtw > 0) {
    const {
      onderdelenNetto,
      arbeidNetto,
      bijkomendNetto,
      spuitwerkNetto,
      milieuNetto,
      totaalExclBtw,
      btwBedrag,
      totaalInclBtw
    } = audatexEindcalculatie;

    const tariefPerAE = tarieven.tariefPerAE || (tarieven.plaatwerktarief / 10) || 8.81;
    const btwRate = (tarieven.btwPercentage || 21.0) / 100;

    // 1. Onderdelen splitsing (proportioneel aan bruto onderdeelprijzen)
    const isOnderdeel = (r: CalculatieRegel) =>
      r.itemType === 'onderdeel' || (r.itemType !== 'bijkomend' && r.onderdeelPrijs > 0);
    const brutoVoor = round(voorRegels.filter(isOnderdeel).reduce((s, r) => s + r.onderdeelPrijs, 0), 2);
    const brutoAchter = round(achterRegels.filter(isOnderdeel).reduce((s, r) => s + r.onderdeelPrijs, 0), 2);
    const brutoOverig = round(overigRegels.filter(isOnderdeel).reduce((s, r) => s + r.onderdeelPrijs, 0), 2);
    const brutoTotaal = round(brutoVoor + brutoAchter + brutoOverig, 2);

    const [onderdelenVoor, onderdelenAchter, onderdelenOverig] = distributeExact(
      onderdelenNetto,
      [brutoVoor, brutoAchter, brutoOverig]
    );

    // 2. Werkplaats-Arbeidsloon splitsing (PL + DM + DIV)
    const plaatVoorAE = voorRegels.reduce((s, r) => s + getPlaatAE(r), 0);
    const demVoorAE = voorRegels.reduce((s, r) => s + getDemAE(r), 0);
    const plaatAchterAE = achterRegels.reduce((s, r) => s + getPlaatAE(r), 0);
    const demAchterAE = achterRegels.reduce((s, r) => s + getDemAE(r), 0);
    const plaatOverigAE = overigRegels.reduce((s, r) => s + getPlaatAE(r), 0);
    const demOverigAE = overigRegels.reduce((s, r) => s + getDemAE(r), 0);

    const rawArbBedrag = (list: CalculatieRegel[]) =>
      list
        .filter(r => r.itemType !== 'spuitwerk' && (getPlaatAE(r) + getDemAE(r)) > 0)
        .reduce((s, r) => s + (r.arbeidsloonBedrag ?? (getPlaatAE(r) + getDemAE(r)) * tariefPerAE), 0);

    const [arbeidVoor, arbeidAchter, arbeidOverig] = distributeExact(
      arbeidNetto,
      [rawArbBedrag(voorRegels), rawArbBedrag(achterRegels), rawArbBedrag(overigRegels)]
    );

    const [plaatBedragVoor, demBedragVoor] = distributeExact(
      arbeidVoor,
      [plaatVoorAE, demVoorAE, 0]
    );
    const [plaatBedragAchter, demBedragAchter] = distributeExact(
      arbeidAchter,
      [plaatAchterAE, demAchterAE, 0]
    );
    const [plaatBedragOverig, demBedragOverig] = distributeExact(
      arbeidOverig,
      [plaatOverigAE, demOverigAE, 0]
    );

    // 3. Bijkomende kosten (TZ 60-74, bijv. Anti-roestbehandeling)
    const getBijk = (list: CalculatieRegel[]) =>
      list.filter(r => r.itemType === 'bijkomend').reduce((s, r) => s + (r.onderdeelPrijs || 0), 0);
    const bijkWeights: [number, number, number] = [getBijk(voorRegels), getBijk(achterRegels), getBijk(overigRegels)];
    const hasBijkWeights = bijkWeights[0] + bijkWeights[1] + bijkWeights[2] > 0;
    const [bijkomendVoor, bijkomendAchter, bijkomendOverig] = distributeExact(
      bijkomendNetto,
      hasBijkWeights ? bijkWeights : [voorRegels.length, achterRegels.length, overigRegels.length]
    );

    // 4. Spuitwerk (Spuitarbeid + Spuitmateriaal inclusief AZT-voorbereidingstijd & materiaalconstante)
    const spuitarbeidNetto = audatexEindcalculatie.spuitarbeidNetto !== undefined && audatexEindcalculatie.spuitarbeidNetto > 0
      ? audatexEindcalculatie.spuitarbeidNetto
      : round(
          (audatexEindcalculatie.spuitLoonTotaalAE || spuitPaneelTotaal) * tariefPerAE,
          2
        );
    const spuitmateriaalNetto = round(spuitwerkNetto - spuitarbeidNetto, 2);

    // Bepaal paneel spuit-AE per materiaalsoort per sectie
    const sumSpuitByMat = (list: CalculatieRegel[], mat: 'metaal' | 'kunststof') =>
      list.filter(r => (r.materiaalSoort || 'metaal') === mat).reduce((s, r) => s + getSpuitAE(r), 0);

    const metaalAEVoor = sumSpuitByMat(voorRegels, 'metaal');
    const metaalAEAchter = sumSpuitByMat(achterRegels, 'metaal');
    const metaalAEOverig = sumSpuitByMat(overigRegels, 'metaal');
    const metaalAETotaal = metaalAEVoor + metaalAEAchter + metaalAEOverig;

    const kunstAEVoor = sumSpuitByMat(voorRegels, 'kunststof');
    const kunstAEAchter = sumSpuitByMat(achterRegels, 'kunststof');
    const kunstAEOverig = sumSpuitByMat(overigRegels, 'kunststof');
    const kunstAETotaal = kunstAEVoor + kunstAEAchter + kunstAEOverig;

    // Verdeel AZT voorbereidingstijd metaal, kunststof en meerlagen naar rato van materiaalsoort
    const vbMetaalAE = audatexEindcalculatie.spuitVoorbereidingMetaalAE || 0;
    const vbKunstAE = audatexEindcalculatie.spuitVoorbereidingKunststofAE || 0;
    const vbMeerAE = audatexEindcalculatie.spuitVoorbereidingMeerlagenAE || 0;
    const totalReportSpuitAE = audatexEindcalculatie.spuitLoonTotaalAE ||
      (spuitPaneelTotaal + vbMetaalAE + vbKunstAE + vbMeerAE);
    const overigeVbAE = Math.max(0, totalReportSpuitAE - spuitPaneelTotaal - vbMetaalAE - vbKunstAE - vbMeerAE);

    const shareMetaal = (ae: number) => (metaalAETotaal > 0 ? vbMetaalAE * (ae / metaalAETotaal) : 0);
    const shareKunst = (ae: number) => (kunstAETotaal > 0 ? vbKunstAE * (ae / kunstAETotaal) : 0);
    const shareMeer = (ae: number) => (spuitPaneelTotaal > 0 ? (vbMeerAE + overigeVbAE) * (ae / spuitPaneelTotaal) : 0);

    const spuitTotaalAEVoor = round(spuitPaneelVoor + shareMetaal(metaalAEVoor) + shareKunst(kunstAEVoor) + shareMeer(spuitPaneelVoor), 1);
    const spuitTotaalAEAchter = round(spuitPaneelAchter + shareMetaal(metaalAEAchter) + shareKunst(kunstAEAchter) + shareMeer(spuitPaneelAchter), 1);
    const spuitTotaalAEOverig = round(spuitPaneelOverig + shareMetaal(metaalAEOverig) + shareKunst(kunstAEOverig) + shareMeer(spuitPaneelOverig), 1);
    const spuitTotaalAESom = round(spuitTotaalAEVoor + spuitTotaalAEAchter + spuitTotaalAEOverig, 1);

    const [spuitArbeidVoor, spuitArbeidAchter, spuitArbeidOverig] = distributeExact(
      spuitarbeidNetto,
      [spuitTotaalAEVoor, spuitTotaalAEAchter, spuitTotaalAEOverig]
    );

    // Verdeel Spuitmateriaal = Variabele lakkosten + Materiaalconstanten (Metaal / Kunststof / Meerlagen)
    const indexFactor = (audatexEindcalculatie.materiaalIndexPerc ?? 100) / 100;
    const constMetaalNet = round((audatexEindcalculatie.materiaalConstanteMetaal || 0) * indexFactor, 2);
    const constKunstNet = round((audatexEindcalculatie.materiaalConstanteKunststof || 0) * indexFactor, 2);
    const constMeerNet = round((audatexEindcalculatie.materiaalConstanteMeerlagen || 0) * indexFactor, 2);
    const totaleConstanteNet = round(constMetaalNet + constKunstNet + constMeerNet, 2);

    let constMatVoor = 0;
    let constMatAchter = 0;
    let constMatOverig = 0;

    if (totaleConstanteNet > 0) {
      if (methode === 'fifty_fifty') {
        const activeSpuit: [number, number, number] = [
          spuitPaneelVoor > 0 ? 1 : 0,
          spuitPaneelAchter > 0 ? 1 : 0,
          spuitPaneelOverig > 0 ? 1 : 0
        ];
        [constMatVoor, constMatAchter, constMatOverig] = distributeExact(totaleConstanteNet, activeSpuit);
      } else if (methode === 'proportioneel_spuittijd') {
        [constMatVoor, constMatAchter, constMatOverig] = distributeExact(
          totaleConstanteNet,
          [spuitTotaalAEVoor, spuitTotaalAEAchter, spuitTotaalAEOverig]
        );
      } else {
        // Solera TZ 143 / standaard: per materiaalsoort toewijzen (metaal aan metaaldelen, kunststof aan kunststofdelen)
        const [mV, mA, mO] = metaalAETotaal > 0
          ? distributeExact(constMetaalNet, [metaalAEVoor, metaalAEAchter, metaalAEOverig])
          : distributeExact(constMetaalNet, [spuitPaneelVoor, spuitPaneelAchter, spuitPaneelOverig]);
        const [kV, kA, kO] = kunstAETotaal > 0
          ? distributeExact(constKunstNet, [kunstAEVoor, kunstAEAchter, kunstAEOverig])
          : distributeExact(constKunstNet, [spuitPaneelVoor, spuitPaneelAchter, spuitPaneelOverig]);
        const [mlV, mlA, mlO] = distributeExact(constMeerNet, [spuitPaneelVoor, spuitPaneelAchter, spuitPaneelOverig]);
        constMatVoor = round(mV + kV + mlV, 2);
        constMatAchter = round(mA + kA + mlA, 2);
        constMatOverig = round(mO + kO + mlO, 2);
      }
    }

    const spuitMateriaalBasisTotaal = round(spuitmateriaalNetto - totaleConstanteNet, 2);

    // Variabele spuitmateriaalkosten verdelen naar rato van de spuitposten (SV1/VERN vs SH/HERST vs S/DEKLAAG vs LB/UITSP)
    let matBasisVoor = 0;
    let matBasisAchter = 0;
    let matBasisOverig = 0;

    if (audatexEindcalculatie.spuitMateriaalPosten && audatexEindcalculatie.spuitMateriaalPosten.length > 0) {
      const catWeight = (list: CalculatieRegel[], cat: string) =>
        list.filter(r => {
          if (r.itemType !== 'spuitwerk') return false;
          if (cat === 'vern') return r.bewerking === 'SP';
          if (cat === 'herst') return r.bewerking === 'SPH';
          if (cat === 'uitspuiten') return r.bewerking === 'UITSP';
          return r.bewerking === 'DIV' || r.bewerking === 'LS';
        }).reduce((s, r) => s + getSpuitAE(r), 0);

      let sumCatAssigned = 0;
      for (const post of audatexEindcalculatie.spuitMateriaalPosten) {
        const scaledPostNet = round(post.bedragBruto * indexFactor, 2);
        const w: [number, number, number] = [
          catWeight(voorRegels, post.categorie),
          catWeight(achterRegels, post.categorie),
          catWeight(overigRegels, post.categorie)
        ];
        const fallbackW: [number, number, number] = (w[0] + w[1] + w[2]) > 0
          ? w
          : [spuitPaneelVoor, spuitPaneelAchter, spuitPaneelOverig];
        const [pV, pA, pO] = distributeExact(scaledPostNet, fallbackW);
        matBasisVoor = round(matBasisVoor + pV, 2);
        matBasisAchter = round(matBasisAchter + pA, 2);
        matBasisOverig = round(matBasisOverig + pO, 2);
        sumCatAssigned = round(sumCatAssigned + pV + pA + pO, 2);
      }
      // Eventueel afrondings- of indexverschil t.o.v. exacte spuitMateriaalBasisTotaal corrigeren
      const diff = round(spuitMateriaalBasisTotaal - sumCatAssigned, 2);
      if (Math.abs(diff) > 0) {
        const [dV, dA, dO] = distributeExact(diff, [spuitPaneelVoor, spuitPaneelAchter, spuitPaneelOverig]);
        matBasisVoor = round(matBasisVoor + dV, 2);
        matBasisAchter = round(matBasisAchter + dA, 2);
        matBasisOverig = round(matBasisOverig + dO, 2);
      }
    } else {
      [matBasisVoor, matBasisAchter, matBasisOverig] = distributeExact(
        spuitMateriaalBasisTotaal,
        [spuitPaneelVoor, spuitPaneelAchter, spuitPaneelOverig]
      );
    }

    const spuitMatTotaalVoor = round(matBasisVoor + constMatVoor, 2);
    const spuitMatTotaalAchter = round(matBasisAchter + constMatAchter, 2);
    const spuitMatTotaalOverig = round(matBasisOverig + constMatOverig, 2);

    // 5. Milieutoeslag splitsing (exact naar rato van totale AE: werkplaats + spuiterij)
    const aeTotaalVoor = plaatVoorAE + demVoorAE + spuitTotaalAEVoor;
    const aeTotaalAchter = plaatAchterAE + demAchterAE + spuitTotaalAEAchter;
    const aeTotaalOverig = plaatOverigAE + demOverigAE + spuitTotaalAEOverig;
    const aeTotaalSom = round(aeTotaalVoor + aeTotaalAchter + aeTotaalOverig, 1);

    const [milieuVoor, milieuAchter, milieuOverig] = distributeExact(
      milieuNetto,
      [aeTotaalVoor, aeTotaalAchter, aeTotaalOverig]
    );

    // 6. Subtotalen Netto per sectie
    const subVoor = round(onderdelenVoor + arbeidVoor + spuitArbeidVoor + spuitMatTotaalVoor + bijkomendVoor + milieuVoor, 2);
    const subAchter = round(onderdelenAchter + arbeidAchter + spuitArbeidAchter + spuitMatTotaalAchter + bijkomendAchter + milieuAchter, 2);
    const subOverig = round(onderdelenOverig + arbeidOverig + spuitArbeidOverig + spuitMatTotaalOverig + bijkomendOverig + milieuOverig, 2);
    const subSom = round(subVoor + subAchter + subOverig, 2);
    const subTotaal = totaalExclBtw;

    // 7. BTW berekening (exact aansluitend op totaal BTW uit Audatex)
    const [btwVoor, btwAchter, btwOverig] = distributeExact(
      btwBedrag || round(subTotaal * btwRate, 2),
      [subVoor, subAchter, subOverig]
    );

    // 8. Totalen Bruto per sectie
    const totVoor = round(subVoor + btwVoor, 2);
    const totAchter = round(subAchter + btwAchter, 2);
    const totOverig = round(subOverig + btwOverig, 2);
    const totTotaal = totaalInclBtw || round(subSom + btwVoor + btwAchter + btwOverig, 2);

    const pct = (val: number) => (totTotaal > 0 ? round((val / totTotaal) * 100, 1) : 0);

    const voorzijde: SectieTotalen = {
      sectie: 'voorzijde',
      label: 'Voorzijde (Dossier A)',
      itemsCount: voorRegels.length,
      spuittijdAE: spuitTotaalAEVoor,
      arbeidPlaatwerkAE: plaatVoorAE,
      arbeidDemontageAE: demVoorAE,
      arbeidTotaalAE: round(aeTotaalVoor, 1),
      spuittijdUren: round(spuitTotaalAEVoor / 10, 2),
      arbeidPlaatwerkUren: round(plaatVoorAE / 10, 2),
      arbeidDemontageUren: round(demVoorAE / 10, 2),
      arbeidTotaalUren: round(aeTotaalVoor / 10, 2),
      bedragPlaatwerk: plaatBedragVoor,
      bedragDemontage: demBedragVoor,
      bedragSpuitarbeid: spuitArbeidVoor,
      bedragTotaalArbeid: round(arbeidVoor + spuitArbeidVoor, 2),
      bedragOnderdelen: onderdelenVoor,
      bedragOnderdelenBruto: brutoVoor,
      bedragBijkomend: bijkomendVoor,
      bedragSpuitmateriaalBasis: matBasisVoor,
      bedragMateriaalconstante: constMatVoor,
      bedragSpuitmateriaalTotaal: spuitMatTotaalVoor,
      bedragKleinMateriaal: 0,
      bedragMilieu: milieuVoor,
      subtotaalNetto: subVoor,
      btwBedrag: btwVoor,
      totaalBruto: totVoor,
      percentageVanTotaal: pct(totVoor)
    };

    const achterzijde: SectieTotalen = {
      sectie: 'achterzijde',
      label: 'Achterzijde (Dossier B)',
      itemsCount: achterRegels.length,
      spuittijdAE: spuitTotaalAEAchter,
      arbeidPlaatwerkAE: plaatAchterAE,
      arbeidDemontageAE: demAchterAE,
      arbeidTotaalAE: round(aeTotaalAchter, 1),
      spuittijdUren: round(spuitTotaalAEAchter / 10, 2),
      arbeidPlaatwerkUren: round(plaatAchterAE / 10, 2),
      arbeidDemontageUren: round(demAchterAE / 10, 2),
      arbeidTotaalUren: round(aeTotaalAchter / 10, 2),
      bedragPlaatwerk: plaatBedragAchter,
      bedragDemontage: demBedragAchter,
      bedragSpuitarbeid: spuitArbeidAchter,
      bedragTotaalArbeid: round(arbeidAchter + spuitArbeidAchter, 2),
      bedragOnderdelen: onderdelenAchter,
      bedragOnderdelenBruto: brutoAchter,
      bedragBijkomend: bijkomendAchter,
      bedragSpuitmateriaalBasis: matBasisAchter,
      bedragMateriaalconstante: constMatAchter,
      bedragSpuitmateriaalTotaal: spuitMatTotaalAchter,
      bedragKleinMateriaal: 0,
      bedragMilieu: milieuAchter,
      subtotaalNetto: subAchter,
      btwBedrag: btwAchter,
      totaalBruto: totAchter,
      percentageVanTotaal: pct(totAchter)
    };

    const overig: SectieTotalen = {
      sectie: 'overig',
      label: 'Overig / Algemeen',
      itemsCount: overigRegels.length,
      spuittijdAE: spuitTotaalAEOverig,
      arbeidPlaatwerkAE: plaatOverigAE,
      arbeidDemontageAE: demOverigAE,
      arbeidTotaalAE: round(aeTotaalOverig, 1),
      spuittijdUren: round(spuitTotaalAEOverig / 10, 2),
      arbeidPlaatwerkUren: round(plaatOverigAE / 10, 2),
      arbeidDemontageUren: round(demOverigAE / 10, 2),
      arbeidTotaalUren: round(aeTotaalOverig / 10, 2),
      bedragPlaatwerk: plaatBedragOverig,
      bedragDemontage: demBedragOverig,
      bedragSpuitarbeid: spuitArbeidOverig,
      bedragTotaalArbeid: round(arbeidOverig + spuitArbeidOverig, 2),
      bedragOnderdelen: onderdelenOverig,
      bedragOnderdelenBruto: brutoOverig,
      bedragBijkomend: bijkomendOverig,
      bedragSpuitmateriaalBasis: matBasisOverig,
      bedragMateriaalconstante: constMatOverig,
      bedragSpuitmateriaalTotaal: spuitMatTotaalOverig,
      bedragKleinMateriaal: 0,
      bedragMilieu: milieuOverig,
      subtotaalNetto: subOverig,
      btwBedrag: btwOverig,
      totaalBruto: totOverig,
      percentageVanTotaal: pct(totOverig)
    };

    const totaal: SectieTotalen = {
      sectie: 'totaal',
      label: 'Totale Audatex Eindcalculatie',
      itemsCount: regels.length,
      spuittijdAE: spuitTotaalAESom,
      arbeidPlaatwerkAE: plaatVoorAE + plaatAchterAE + plaatOverigAE,
      arbeidDemontageAE: demVoorAE + demAchterAE + demOverigAE,
      arbeidTotaalAE: aeTotaalSom,
      spuittijdUren: round(spuitTotaalAESom / 10, 2),
      arbeidPlaatwerkUren: round((plaatVoorAE + plaatAchterAE + plaatOverigAE) / 10, 2),
      arbeidDemontageUren: round((demVoorAE + demAchterAE + demOverigAE) / 10, 2),
      arbeidTotaalUren: round(aeTotaalSom / 10, 2),
      bedragPlaatwerk: round(plaatBedragVoor + plaatBedragAchter + plaatBedragOverig, 2),
      bedragDemontage: round(demBedragVoor + demBedragAchter + demBedragOverig, 2),
      bedragSpuitarbeid: spuitarbeidNetto,
      bedragTotaalArbeid: round(arbeidNetto + spuitarbeidNetto, 2),
      bedragOnderdelen: onderdelenNetto,
      bedragOnderdelenBruto: audatexEindcalculatie.onderdelenBruto || brutoTotaal,
      bedragBijkomend: bijkomendNetto,
      bedragSpuitmateriaalBasis: spuitMateriaalBasisTotaal,
      bedragMateriaalconstante: totaleConstanteNet,
      bedragSpuitmateriaalTotaal: spuitmateriaalNetto,
      bedragKleinMateriaal: 0,
      bedragMilieu: milieuNetto,
      subtotaalNetto: subTotaal,
      btwBedrag: btwBedrag || round(btwVoor + btwAchter + btwOverig, 2),
      totaalBruto: totTotaal,
      percentageVanTotaal: 100
    };

    return {
      voorzijde,
      achterzijde,
      overig,
      totaal,
      soleraInfo: {
        constanteVoor: constMatVoor,
        constanteAchter: constMatAchter,
        constanteOverig: constMatOverig,
        invoerTekst143,
        advies
      }
    };
  }

  // =========================================================================
  // 2. STANDAARD REKENMETHODE (indien geen officiële Audatex eindcalculatie aanwezig)
  // =========================================================================
  function berekenEnkeleSectie(
    sectieKey: SectieType | 'totaal',
    label: string,
    sectieRegels: CalculatieRegel[],
    toegekendeConstante: number,
    milieuDeel: number
  ): SectieTotalen {
    const itemsCount = sectieRegels.length;

    const plaatwerkAE = sectieRegels.reduce((s, r) => s + getPlaatAE(r), 0);
    const demontageAE = sectieRegels.reduce((s, r) => s + getDemAE(r), 0);
    const spuitAE = sectieRegels.reduce((s, r) => s + getSpuitAE(r), 0);
    const arbeidTotaalAE = plaatwerkAE + demontageAE + spuitAE;

    const plaatwerkUren = plaatwerkAE / 10;
    const demontageUren = demontageAE / 10;
    const spuitUren = spuitAE / 10;
    const arbeidTotaalUren = arbeidTotaalAE / 10;

    const tariefPlaatwerkPerAE = tarieven.plaatwerktarief / 10;
    const tariefDemontagePerAE = tarieven.demontagetarief / 10;
    const tariefSpuitenPerAE = tarieven.spuittarief / 10;
    const tariefSpuitmatPerAE = tarieven.spuitmateriaaltarief / 10;

    const bedragPlaatwerk = plaatwerkAE * tariefPlaatwerkPerAE;
    const bedragDemontage = demontageAE * tariefDemontagePerAE;
    const bedragSpuitarbeid = spuitAE * tariefSpuitenPerAE;
    const bedragTotaalArbeid = bedragPlaatwerk + bedragDemontage + bedragSpuitarbeid;

    const bedragOnderdelenBruto = sectieRegels
      .filter(r => r.itemType !== 'bijkomend')
      .reduce((s, r) => s + (r.onderdeelPrijs || 0), 0);
    const kortingPerc = tarieven.onderdelenKortingPerc || 0;
    const bedragOnderdelen = bedragOnderdelenBruto * (1 - kortingPerc / 100);
    const bedragBijkomend = sectieRegels
      .filter(r => r.itemType === 'bijkomend')
      .reduce((s, r) => s + (r.onderdeelPrijs || 0), 0);

    const bedragSpuitmateriaalBasis = sectieRegels.reduce((s, r) => {
      if (r.spuitmateriaalBedrag !== undefined && r.spuitmateriaalBedrag > 0) {
        return s + r.spuitmateriaalBedrag;
      }
      return s + getSpuitAE(r) * tariefSpuitmatPerAE;
    }, 0);

    const bedragMateriaalconstante = itemsCount > 0 || sectieKey === 'totaal' ? toegekendeConstante : 0;
    const bedragSpuitmateriaalTotaal = bedragSpuitmateriaalBasis + bedragMateriaalconstante;

    // Kleinmateriaal standaard in Audatex (TZ 28: % van onderdelenbedrag, of fallback op arbeid indien geen onderdelen)
    const bedragKleinMateriaal = (bedragOnderdelenBruto > 0 ? bedragOnderdelen : bedragTotaalArbeid) * (tarieven.kleinMateriaalPerc / 100);
    const bedragMilieu = itemsCount > 0 || sectieKey === 'totaal' ? milieuDeel : 0;

    const subtotaalNetto = bedragTotaalArbeid + bedragOnderdelen + bedragBijkomend + bedragSpuitmateriaalTotaal + bedragKleinMateriaal + bedragMilieu;
    const btwBedrag = subtotaalNetto * (tarieven.btwPercentage / 100);
    const totaalBruto = subtotaalNetto + btwBedrag;

    return {
      sectie: sectieKey,
      label,
      itemsCount,
      spuittijdAE: round(spuitAE, 1),
      arbeidPlaatwerkAE: round(plaatwerkAE, 1),
      arbeidDemontageAE: round(demontageAE, 1),
      arbeidTotaalAE: round(arbeidTotaalAE, 1),
      spuittijdUren: round(spuitUren, 2),
      arbeidPlaatwerkUren: round(plaatwerkUren, 2),
      arbeidDemontageUren: round(demontageUren, 2),
      arbeidTotaalUren: round(arbeidTotaalUren, 2),
      bedragPlaatwerk: round(bedragPlaatwerk, 2),
      bedragDemontage: round(bedragDemontage, 2),
      bedragSpuitarbeid: round(bedragSpuitarbeid, 2),
      bedragTotaalArbeid: round(bedragTotaalArbeid, 2),
      bedragOnderdelen: round(bedragOnderdelen, 2),
      bedragOnderdelenBruto: round(bedragOnderdelenBruto, 2),
      bedragBijkomend: round(bedragBijkomend, 2),
      bedragSpuitmateriaalBasis: round(bedragSpuitmateriaalBasis, 2),
      bedragMateriaalconstante: round(bedragMateriaalconstante, 2),
      bedragSpuitmateriaalTotaal: round(bedragSpuitmateriaalTotaal, 2),
      bedragKleinMateriaal: round(bedragKleinMateriaal, 2),
      bedragMilieu: round(bedragMilieu, 2),
      subtotaalNetto: round(subtotaalNetto, 2),
      btwBedrag: round(btwBedrag, 2),
      totaalBruto: round(totaalBruto, 2),
      percentageVanTotaal: 0
    };
  }

  const [milieuVoor, milieuAchter, milieuOverig] = distributeExact(
    tarieven.milieutoeslag,
    [voorRegels.length, achterRegels.length, overigRegels.length]
  );

  const voorzijde = berekenEnkeleSectie('voorzijde', 'Voorzijde (Dossier A)', voorRegels, constanteVoor, milieuVoor);
  const achterzijde = berekenEnkeleSectie('achterzijde', 'Achterzijde (Dossier B)', achterRegels, constanteAchter, milieuAchter);
  const overig = berekenEnkeleSectie('overig', 'Overig / Algemeen', overigRegels, constanteOverig, milieuOverig);

  const totaalConstante = methode === 'beide_volledig' ? (constanteVoor + constanteAchter) : basisConstante;
  const totaal = berekenEnkeleSectie('totaal', 'Totale Calculatie', regels, totaalConstante, tarieven.milieutoeslag);

  if (totaal.totaalBruto > 0) {
    voorzijde.percentageVanTotaal = round((voorzijde.totaalBruto / totaal.totaalBruto) * 100, 1);
    achterzijde.percentageVanTotaal = round((achterzijde.totaalBruto / totaal.totaalBruto) * 100, 1);
    overig.percentageVanTotaal = round((overig.totaalBruto / totaal.totaalBruto) * 100, 1);
    totaal.percentageVanTotaal = 100;
  }

  return {
    voorzijde,
    achterzijde,
    overig,
    totaal,
    soleraInfo: {
      constanteVoor: round(constanteVoor, 2),
      constanteAchter: round(constanteAchter, 2),
      constanteOverig: round(constanteOverig, 2),
      invoerTekst143,
      advies
    }
  };
}

export function formatEuro(val: number | undefined): string {
  if (val === undefined || isNaN(val)) return '€ 0,00';
  return new Intl.NumberFormat('nl-NL', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(val);
}

/**
 * Formatteert Arbeidseenheden (AE) voor Audatex
 * 1 AE = 6 minuten, 10 AE = 1 uur
 */
export function formatAE(val: number | undefined, showHours: boolean = false): string {
  if (val === undefined || isNaN(val)) return '0 AE';
  const isWhole = Math.abs(val - Math.round(val)) < 0.05;
  const aeStr = isWhole ? `${Math.round(val)} AE` : `${val.toFixed(1).replace('.', ',')} AE`;
  
  if (showHours) {
    const uren = val / 10;
    return `${aeStr} (${uren.toFixed(1).replace('.', ',')} u)`;
  }
  return aeStr;
}

export function formatAELabel(val: number | undefined): string {
  if (val === undefined || isNaN(val)) return '0 AE (0,0 u)';
  const aeFormatted = formatAE(val, false);
  const uren = (val / 10).toFixed(1).replace('.', ',');
  const min = Math.round(val * 6);
  return `${aeFormatted} (${uren} u • ${min} min)`;
}

export function formatUren(val: number | undefined): string {
  if (val === undefined || isNaN(val)) return '0,00 u';
  return `${val.toFixed(2).replace('.', ',')} u`;
}

export function aeNaarUren(ae: number): number {
  return ae / 10;
}

export function urenNaarAE(uren: number): number {
  return Math.round(uren * 10);
}

export function formatTariefPerAE(uurtarief: number): string {
  const perAE = uurtarief / 10;
  return `${formatEuro(perAE)} / AE (${formatEuro(uurtarief)} / uur)`;
}
