import React from 'react';

interface LicensePlateBadgeProps {
  plate: string;
  size?: 'sm' | 'md' | 'lg';
}

export const LicensePlateBadge: React.FC<LicensePlateBadgeProps> = ({ plate, size = 'md' }) => {
  const formattedPlate = (plate || 'ONBEKEND').toUpperCase().trim();
  
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1.5 border-[1.5px]',
    md: 'text-sm px-2.5 py-1 gap-2 border-2',
    lg: 'text-lg px-4 py-1.5 gap-2.5 border-[2.5px]'
  };

  const blueSizeClasses = {
    sm: 'text-[9px] px-1',
    md: 'text-[10px] px-1.5',
    lg: 'text-xs px-2'
  };

  return (
    <div className={`inline-flex items-center font-mono font-black tracking-wider uppercase bg-[#ffcc00] text-black border-black rounded shadow-sm select-none ${sizeClasses[size]}`}>
      {/* EU NL Flag strip */}
      <div className={`bg-[#003399] text-white flex flex-col items-center justify-center -ml-1 -my-1 rounded-l-xs font-sans font-bold leading-none ${blueSizeClasses[size]}`}>
        <span className="text-[7px] text-[#ffcc00] leading-none mb-0.5">★</span>
        <span className="tracking-tighter">NL</span>
      </div>
      <span className="font-bold tracking-widest">{formattedPlate}</span>
    </div>
  );
};
