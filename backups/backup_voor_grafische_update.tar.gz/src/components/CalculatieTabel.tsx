import React, { useState } from 'react';
import { CalculatieRegel, SectieType, BewerkingType } from '../types/audatex';
import { formatEuro, formatUren, formatAE } from '../utils/calculator';
import { 
  ArrowLeftRight, 
  Trash2, 
  Plus, 
  Paintbrush, 
  Wrench, 
  Tag, 
  Search, 
  CornerDownRight, 
  ChevronRight,
  Filter,
  Clock
} from 'lucide-react';

interface CalculatieTabelProps {
  regels: CalculatieRegel[];
  onUpdateRegels: (regels: CalculatieRegel[]) => void;
  spuittarief: number;
}

export const CalculatieTabel: React.FC<CalculatieTabelProps> = ({
  regels,
  onUpdateRegels,
  spuittarief
}) => {
  const [filterSectie, setFilterSectie] = useState<string>('alle');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddRow, setShowAddRow] = useState<boolean>(false);

  // New row form state (primair in AE: 1 AE = 6 min, 10 AE = 1 uur)
  const [newOmschrijving, setNewOmschrijving] = useState('');
  const [newCode, setNewCode] = useState('');
  const [newSectie, setNewSectie] = useState<SectieType>('voorzijde');
  const [newBewerking, setNewBewerking] = useState<BewerkingType>('VERN');
  const [newOnderdeelPrijs, setNewOnderdeelPrijs] = useState<number>(0);
  const [newPlaatwerkAE, setNewPlaatwerkAE] = useState<number>(0);
  const [newDemontageAE, setNewDemontageAE] = useState<number>(0);
  const [newSpuittijdAE, setNewSpuittijdAE] = useState<number>(0);

  const counts = {
    alle: regels.length,
    voorzijde: regels.filter(r => r.sectie === 'voorzijde').length,
    achterzijde: regels.filter(r => r.sectie === 'achterzijde').length,
    overig: regels.filter(r => r.sectie === 'overig').length,
  };

  const filteredRegels = regels.filter(regel => {
    if (filterSectie !== 'alle' && regel.sectie !== filterSectie) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        regel.omschrijving.toLowerCase().includes(q) ||
        (regel.code && regel.code.toLowerCase().includes(q)) ||
        (regel.artikelnummer && regel.artikelnummer.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleToggleSectie = (id: string, currentSectie: SectieType) => {
    const nextSectie: SectieType = 
      currentSectie === 'voorzijde' ? 'achterzijde' :
      currentSectie === 'achterzijde' ? 'overig' : 'voorzijde';

    const updated = regels.map(r => r.id === id ? { ...r, sectie: nextSectie } : r);
    onUpdateRegels(updated);
  };

  const handleSetSectie = (id: string, sectie: SectieType) => {
    const updated = regels.map(r => r.id === id ? { ...r, sectie } : r);
    onUpdateRegels(updated);
  };

  const handleDeleteRegel = (id: string) => {
    const updated = regels.filter(r => r.id !== id);
    onUpdateRegels(updated);
  };

  const handleAddRegel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOmschrijving.trim()) return;

    const spuitAE = Number(newSpuittijdAE) || 0;
    const plaatAE = Number(newPlaatwerkAE) || 0;
    const demAE = Number(newDemontageAE) || 0;

    const newRegel: CalculatieRegel = {
      id: 'custom-' + Date.now(),
      code: newCode || '9999',
      omschrijving: newOmschrijving.trim(),
      sectie: newSectie,
      bewerking: newBewerking,
      onderdeelPrijs: Number(newOnderdeelPrijs) || 0,
      arbeidPlaatwerkAE: plaatAE,
      arbeidDemontageAE: demAE,
      spuittijdAE: spuitAE,
      arbeidPlaatwerkUren: plaatAE / 10,
      arbeidDemontageUren: demAE / 10,
      spuittijdUren: spuitAE / 10
    };

    onUpdateRegels([...regels, newRegel]);
    setNewOmschrijving('');
    setNewCode('');
    setNewOnderdeelPrijs(0);
    setNewPlaatwerkAE(0);
    setNewDemontageAE(0);
    setNewSpuittijdAE(0);
    setShowAddRow(false);
  };

  const getBewerkingBadge = (bewerking: BewerkingType) => {
    switch (bewerking) {
      case 'VERN':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">VERN</span>;
      case 'HERST':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">HERST</span>;
      case 'DM':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">D+M</span>;
      case 'SP':
      case 'SPH':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">{bewerking}</span>;
      case 'UITSP':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">UITSP</span>;
      case 'LS':
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-200">LS (Spot)</span>;
      default:
        return <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200">DIV</span>;
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
      {/* Controls header */}
      <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div>
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <span>Calculatieposities & Bewerkingen</span>
            <span className="text-[11px] font-mono font-medium px-1.5 py-0.5 rounded bg-white text-slate-700 border border-slate-300">
              {regels.length} regels
            </span>
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Klik op een toewijzing om een positie te verplaatsen tussen Voorzijde, Achterzijde of Overig
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddRow(!showAddRow)}
            className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded bg-blue-600 hover:bg-blue-700 text-white transition-colors shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            Positie Toevoegen
          </button>
        </div>
      </div>

      {/* Filter and search bar */}
      <div className="px-3.5 py-2 bg-white border-b border-slate-200 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2.5">
        {/* Filter buttons */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setFilterSectie('alle')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              filterSectie === 'alle'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Alle posities <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-slate-200 text-slate-800">{counts.alle}</span>
          </button>

          <button
            onClick={() => setFilterSectie('voorzijde')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              filterSectie === 'voorzijde'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span className="w-2 h-2 rounded-xs bg-blue-500"></span>
            Voorzijde <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-blue-100 text-blue-900">{counts.voorzijde}</span>
          </button>

          <button
            onClick={() => setFilterSectie('achterzijde')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              filterSectie === 'achterzijde'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span className="w-2 h-2 rounded-xs bg-indigo-500"></span>
            Achterzijde <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-indigo-100 text-indigo-900">{counts.achterzijde}</span>
          </button>

          <button
            onClick={() => setFilterSectie('overig')}
            className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              filterSectie === 'overig'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Overig <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-slate-200 text-slate-800">{counts.overig}</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[220px]">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Zoek onderdeel of code..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded pl-8 pr-2.5 py-1 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600"
          />
        </div>
      </div>

      {/* Add row form */}
      {showAddRow && (
        <form onSubmit={handleAddRegel} className="p-4 bg-slate-50 border-b border-slate-200 animate-fadeIn">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-blue-600" />
              Nieuwe bewerking / onderdeel toevoegen
            </h4>
            <button
              type="button"
              onClick={() => setShowAddRow(false)}
              className="text-xs text-slate-500 hover:text-slate-800"
            >
              Annuleren
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-8 gap-3">
            <div className="lg:col-span-1">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Code</label>
              <input
                type="text"
                placeholder="0101"
                value={newCode}
                onChange={(e) => setNewCode(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
            </div>

            <div className="lg:col-span-3">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Omschrijving</label>
              <input
                type="text"
                required
                placeholder="bv. Voorbumper / Achterklep / Koplamp"
                value={newOmschrijving}
                onChange={(e) => setNewOmschrijving(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
            </div>

            <div className="lg:col-span-1">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Sectie</label>
              <select
                value={newSectie}
                onChange={(e) => setNewSectie(e.target.value as SectieType)}
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              >
                <option value="voorzijde">Voorzijde</option>
                <option value="achterzijde">Achterzijde</option>
                <option value="overig">Overig</option>
              </select>
            </div>

            <div className="lg:col-span-1">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Bewerking</label>
              <select
                value={newBewerking}
                onChange={(e) => setNewBewerking(e.target.value as BewerkingType)}
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              >
                <option value="VERN">VERN (Nieuw)</option>
                <option value="HERST">HERST (Plaatwerk)</option>
                <option value="DM">D+M (De/montage)</option>
                <option value="SP">SP (Spuiten)</option>
                <option value="SPH">SPH (Spuiten na herstel)</option>
                <option value="UITSP">LB / UITSP (Uitspuiten)</option>
                <option value="LS">LS (Spot-Repair)</option>
                <option value="DIV">DIV (Overig)</option>
              </select>
            </div>

            <div className="lg:col-span-1">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Spuittijd (AE)</label>
              <input
                type="number"
                step="1"
                min="0"
                value={newSpuittijdAE || ''}
                onChange={(e) => setNewSpuittijdAE(parseFloat(e.target.value) || 0)}
                placeholder="bv. 18"
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 font-semibold focus:outline-none focus:border-blue-600"
              />
              <span className="text-[10px] text-slate-400">
                {newSpuittijdAE > 0 ? `${(newSpuittijdAE / 10).toFixed(1)} u` : '10 AE = 1u'}
              </span>
            </div>

            <div className="lg:col-span-1">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Plaatwerk (AE)</label>
              <input
                type="number"
                step="1"
                min="0"
                value={newPlaatwerkAE || ''}
                onChange={(e) => setNewPlaatwerkAE(parseFloat(e.target.value) || 0)}
                placeholder="0"
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
            </div>

            <div className="lg:col-span-1">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">De/Mont (AE)</label>
              <input
                type="number"
                step="1"
                min="0"
                value={newDemontageAE || ''}
                onChange={(e) => setNewDemontageAE(parseFloat(e.target.value) || 0)}
                placeholder="0"
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
            </div>

            <div className="lg:col-span-1">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Deel Prijs (€)</label>
              <input
                type="number"
                step="1"
                min="0"
                value={newOnderdeelPrijs || ''}
                onChange={(e) => setNewOnderdeelPrijs(parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-blue-600"
              />
            </div>
          </div>

          <div className="mt-3 flex justify-end">
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded shadow-2xs"
            >
              Regel Toevoegen
            </button>
          </div>
        </form>
      )}

      {/* Regels Tabel */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
            <tr>
              <th className="py-2.5 px-3.5 w-16">Code</th>
              <th className="py-2.5 px-3.5">Omschrijving / Onderdeel</th>
              <th className="py-2.5 px-3.5 w-28">Toewijzing</th>
              <th className="py-2.5 px-3.5 w-24">Bewerking</th>
              <th className="py-2.5 px-3.5 text-right w-24">Spuittijd (AE)</th>
              <th className="py-2.5 px-3.5 text-right w-20">Plaatwerk (AE)</th>
              <th className="py-2.5 px-3.5 text-right w-20">De/Mont (AE)</th>
              <th className="py-2.5 px-3.5 text-right w-24">Onderdeel</th>
              <th className="py-2.5 px-3.5 text-center w-28">Actie</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-800">
            {filteredRegels.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-8 text-center text-slate-400">
                  Geen regels gevonden voor het huidige filter of zoekopdracht.
                </td>
              </tr>
            ) : (
              filteredRegels.map((regel, idx) => {
                const spuitAE = regel.spuittijdAE !== undefined ? regel.spuittijdAE : Math.round((regel.spuittijdUren || 0) * 10);
                const plaatAE = regel.arbeidPlaatwerkAE !== undefined ? regel.arbeidPlaatwerkAE : Math.round((regel.arbeidPlaatwerkUren || 0) * 10);
                const demAE = regel.arbeidDemontageAE !== undefined ? regel.arbeidDemontageAE : Math.round((regel.arbeidDemontageUren || 0) * 10);

                return (
                  <tr 
                    key={regel.id} 
                    className="hover:bg-slate-50/80 transition-colors"
                  >
                    {/* Code */}
                    <td className="py-2.5 px-3.5 font-mono text-slate-500 font-medium">
                      {regel.code || `${idx + 1}`.padStart(3, '0')}
                    </td>

                    {/* Omschrijving */}
                    <td className="py-2.5 px-3.5">
                      <div className="font-semibold text-slate-900 flex flex-wrap items-center gap-1.5">
                        <span>{regel.omschrijving}</span>
                        {regel.spuitFase && (
                          <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                            {regel.spuitFase}
                          </span>
                        )}
                        {regel.materiaalSoort && (
                          <span className="text-[10px] font-sans text-slate-600 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200 capitalize">
                            {regel.materiaalSoort}
                          </span>
                        )}
                        {regel.artikelnummer && (
                          <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                            {regel.artikelnummer}
                          </span>
                        )}
                      </div>
                      {regel.opmerking && (
                        <div className="text-[10px] text-slate-500 mt-0.5 italic">
                          {regel.opmerking}
                        </div>
                      )}
                    </td>

                    {/* Sectie Badge - Clickable to cycle */}
                    <td className="py-2.5 px-3.5">
                      <button
                        type="button"
                        onClick={() => handleToggleSectie(regel.id, regel.sectie)}
                        title="Klik om te wisselen tussen Voor, Achter en Overig"
                        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-semibold border transition-colors cursor-pointer ${
                          regel.sectie === 'voorzijde'
                            ? 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'
                            : regel.sectie === 'achterzijde'
                            ? 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100'
                            : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-xs ${
                          regel.sectie === 'voorzijde' ? 'bg-blue-600' :
                          regel.sectie === 'achterzijde' ? 'bg-indigo-600' : 'bg-slate-500'
                        }`} />
                        <span className="capitalize">{regel.sectie}</span>
                      </button>
                    </td>

                    {/* Bewerking */}
                    <td className="py-2.5 px-3.5">
                      {getBewerkingBadge(regel.bewerking)}
                    </td>

                    {/* Spuittijd in AE */}
                    <td className="py-2.5 px-3.5 text-right font-mono">
                      {spuitAE > 0 ? (
                        <div className="inline-flex flex-col items-end">
                          <span className="font-extrabold text-slate-900 inline-flex items-center gap-1">
                            <Paintbrush className="w-3 h-3 text-blue-600" />
                            {formatAE(spuitAE)}
                          </span>
                          <span className="text-[10px] text-slate-400 font-normal">
                            {(spuitAE / 10).toFixed(1)} u
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>

                    {/* Plaatwerk in AE */}
                    <td className="py-2.5 px-3.5 text-right font-mono text-slate-700">
                      {plaatAE > 0 ? (
                        <div className="inline-flex flex-col items-end">
                          <span className="font-semibold text-slate-800">{formatAE(plaatAE)}</span>
                          <span className="text-[10px] text-slate-400 font-normal">{(plaatAE / 10).toFixed(1)} u</span>
                        </div>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>

                    {/* Demontage in AE */}
                    <td className="py-2.5 px-3.5 text-right font-mono text-slate-700">
                      {demAE > 0 ? (
                        <div className="inline-flex flex-col items-end">
                          <span className="font-semibold text-slate-800">{formatAE(demAE)}</span>
                          <span className="text-[10px] text-slate-400 font-normal">{(demAE / 10).toFixed(1)} u</span>
                        </div>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>

                    {/* Onderdeelprijs */}
                    <td className="py-2.5 px-3.5 text-right font-mono">
                      {regel.onderdeelPrijs > 0 ? (
                        <span className="font-bold text-slate-900">
                          {formatEuro(regel.onderdeelPrijs)}
                        </span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>

                    {/* Acties */}
                    <td className="py-2.5 px-3.5 text-center">
                    <div className="flex items-center justify-center gap-1">
                      {regel.sectie !== 'voorzijde' && (
                        <button
                          onClick={() => handleSetSectie(regel.id, 'voorzijde')}
                          title="Naar Voorzijde verplaatsen"
                          className="px-1.5 py-0.5 rounded bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 text-[10px] font-bold transition-colors"
                        >
                          Voor
                        </button>
                      )}
                      {regel.sectie !== 'achterzijde' && (
                        <button
                          onClick={() => handleSetSectie(regel.id, 'achterzijde')}
                          title="Naar Achterzijde verplaatsen"
                          className="px-1.5 py-0.5 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[10px] font-bold transition-colors"
                        >
                          Achter
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteRegel(regel.id)}
                        title="Verwijder regel"
                        className="p-1 rounded hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors ml-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })
          )}
          </tbody>
        </table>
      </div>

      {/* Footer hint */}
      <div className="p-3 bg-slate-50 text-slate-600 text-[11px] flex items-center justify-between border-t border-slate-200">
        <div className="flex items-center gap-1.5">
          <CornerDownRight className="w-3.5 h-3.5 text-blue-600" />
          <span>Tip: Spuittijd en materiaalkosten worden in realtime herberekend bij het aanpassen of wisselen van een sectie.</span>
        </div>
        <div className="text-slate-500">
          Totaal getoond: <span className="text-slate-900 font-bold">{filteredRegels.length}</span> van {regels.length}
        </div>
      </div>
    </div>
  );
};
