import React, { useState } from 'react';
import { DossierMeta, Tarieven, SectieTotalen, MateriaalconstanteMethode, RdwVoertuigData } from '../types/audatex';
import { formatEuro, formatUren, formatAE } from '../utils/calculator';
import { exportFinancieelRapportPdf } from '../utils/pdfExporter';
import { LicensePlateBadge } from './LicensePlateBadge';
import { 
  Printer, 
  Download, 
  FileDown,
  Copy, 
  Check, 
  FileText, 
  CheckCircle2, 
  ShieldCheck, 
  Car, 
  Calendar, 
  Building2,
  Share2,
  Clock
} from 'lucide-react';

interface FinancieelRapportProps {
  meta: DossierMeta;
  tarieven: Tarieven;
  voorzijde: SectieTotalen;
  achterzijde: SectieTotalen;
  overig: SectieTotalen;
  totaal: SectieTotalen;
  soleraInfo: {
    constanteVoor: number;
    constanteAchter: number;
    constanteOverig: number;
    invoerTekst143: string;
    advies: string;
  };
  methode: MateriaalconstanteMethode;
  rdw?: RdwVoertuigData;
}

export const FinancieelRapport: React.FC<FinancieelRapportProps> = ({
  meta,
  tarieven,
  voorzijde,
  achterzijde,
  overig,
  totaal,
  soleraInfo,
  methode,
  rdw
}) => {
  const [copiedEmail, setCopiedEmail] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleExportPdf = () => {
    exportFinancieelRapportPdf({
      meta,
      tarieven,
      voorzijde,
      achterzijde,
      overig,
      totaal,
      soleraInfo,
      methode,
      rdw
    });
  };

  const handleExportCSV = () => {
    const csvRows = [
      ['SOLERA AUDATEX SCHADECALCULATIE - VOOR/ACHTERZIJDE SPLITSINGSRAPPORT'],
      ['Audatex norm', '1 AE = 6 minuten • 10 AE = 1 uur'],
      ['Kenteken', meta.kenteken, 'Voertuig', meta.merkModel],
      ['Calculatienummer', meta.calculatienummer, 'Dossiernummer', meta.dossiernummer],
      ['Datum calculatie', meta.datumCalculatie, 'Expert / Hersteller', meta.expertHersteller],
      ['Laksoort', meta.laksoort, 'Kleurcode', meta.kleurcode],
      [],
      ['POST', 'VOORZIJDE (DOSSIER A)', 'ACHTERZIJDE (DOSSIER B)', 'OVERIG', 'TOTAAL GECOMBINEERD'],
      ['Spuittijd (AE)', voorzijde.spuittijdAE, achterzijde.spuittijdAE, overig.spuittijdAE, totaal.spuittijdAE],
      ['Spuittijd (uren)', voorzijde.spuittijdUren, achterzijde.spuittijdUren, overig.spuittijdUren, totaal.spuittijdUren],
      ['Spuitarbeid (€)', voorzijde.bedragSpuitarbeid, achterzijde.bedragSpuitarbeid, overig.bedragSpuitarbeid, totaal.bedragSpuitarbeid],
      ['Plaatwerk (AE)', voorzijde.arbeidPlaatwerkAE, achterzijde.arbeidPlaatwerkAE, overig.arbeidPlaatwerkAE, totaal.arbeidPlaatwerkAE],
      ['Plaatwerk bedrag (€)', voorzijde.bedragPlaatwerk, achterzijde.bedragPlaatwerk, overig.bedragPlaatwerk, totaal.bedragPlaatwerk],
      ['De/montage (AE)', voorzijde.arbeidDemontageAE, achterzijde.arbeidDemontageAE, overig.arbeidDemontageAE, totaal.arbeidDemontageAE],
      ['De/montage bedrag (€)', voorzijde.bedragDemontage, achterzijde.bedragDemontage, overig.bedragDemontage, totaal.bedragDemontage],
      ['TOTAAL ARBEID (€)', voorzijde.bedragTotaalArbeid, achterzijde.bedragTotaalArbeid, overig.bedragTotaalArbeid, totaal.bedragTotaalArbeid],
      ['Nieuwe Onderdelen (€)', voorzijde.bedragOnderdelen, achterzijde.bedragOnderdelen, overig.bedragOnderdelen, totaal.bedragOnderdelen],
      ['Lakmateriaal basis (€)', voorzijde.bedragSpuitmateriaalBasis, achterzijde.bedragSpuitmateriaalBasis, overig.bedragSpuitmateriaalBasis, totaal.bedragSpuitmateriaalBasis],
      ['AZT Materiaalconstante TZ 51 (€)', voorzijde.bedragMateriaalconstante, achterzijde.bedragMateriaalconstante, overig.bedragMateriaalconstante, totaal.bedragMateriaalconstante],
      ['TOTAAL SPUITMATERIAAL (€)', voorzijde.bedragSpuitmateriaalTotaal, achterzijde.bedragSpuitmateriaalTotaal, overig.bedragSpuitmateriaalTotaal, totaal.bedragSpuitmateriaalTotaal],
      ['Klein materiaal (€)', voorzijde.bedragKleinMateriaal, achterzijde.bedragKleinMateriaal, overig.bedragKleinMateriaal, totaal.bedragKleinMateriaal],
      ['Milieutoeslag (€)', voorzijde.bedragMilieu, achterzijde.bedragMilieu, overig.bedragMilieu, totaal.bedragMilieu],
      ['SUBTOTAAL NETTO (€)', voorzijde.subtotaalNetto, achterzijde.subtotaalNetto, overig.subtotaalNetto, totaal.subtotaalNetto],
      ['BTW (21%) (€)', voorzijde.btwBedrag, achterzijde.btwBedrag, overig.btwBedrag, totaal.btwBedrag],
      ['TOTAAL SCHADEBEDRAG BRUTO (€)', voorzijde.totaalBruto, achterzijde.totaalBruto, overig.totaalBruto, totaal.totaalBruto],
      ['Aandeel (%)', `${voorzijde.percentageVanTotaal}%`, `${achterzijde.percentageVanTotaal}%`, `${overig.percentageVanTotaal}%`, '100%'],
      [],
      ['SOLERA RICHTLIJN TEKSTZONE 143'],
      ['Invoerinstructie', soleraInfo.invoerTekst143],
      ['Toelichting', soleraInfo.advies]
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map(e => e.join(';')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `audatex_split_${meta.kenteken}_${meta.calculatienummer}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyEmailSummary = () => {
    const text = `SCHADECALCULATIE SPLITSINGSRAPPORT (SOLERA AUDATEX)
Voertuig: ${meta.merkModel}
Kenteken: ${meta.kenteken}
Calculatienummer: ${meta.calculatienummer}
Dossiernummer: ${meta.dossiernummer}
Datum: ${meta.datumCalculatie}
Eenheid: Arbeidseenheden (1 AE = 6 min • 10 AE = 1 uur)

OVERZICHT SPLITSING:
-----------------------------------------------------------
1. VOORZIJDE (Dossier A):
- Spuittijd: ${formatAE(voorzijde.spuittijdAE, true)} (${formatEuro(voorzijde.bedragSpuitarbeid)})
- Spuitmateriaal (incl AZT constante ${formatEuro(soleraInfo.constanteVoor)}): ${formatEuro(voorzijde.bedragSpuitmateriaalTotaal)}
- Onderdelen: ${formatEuro(voorzijde.bedragOnderdelen)}
- Arbeid (PL + DM): ${formatAE(voorzijde.arbeidPlaatwerkAE + voorzijde.arbeidDemontageAE, true)} (${formatEuro(voorzijde.bedragPlaatwerk + voorzijde.bedragDemontage)})
- Subtotaal Netto: ${formatEuro(voorzijde.subtotaalNetto)}
- TOTAAL BRUTO (INCL BTW): ${formatEuro(voorzijde.totaalBruto)} (${voorzijde.percentageVanTotaal}%)

2. ACHTERZIJDE (Dossier B):
- Spuittijd: ${formatAE(achterzijde.spuittijdAE, true)} (${formatEuro(achterzijde.bedragSpuitarbeid)})
- Spuitmateriaal (AZT constante ${formatEuro(soleraInfo.constanteAchter)}): ${formatEuro(achterzijde.bedragSpuitmateriaalTotaal)}
- Onderdelen: ${formatEuro(achterzijde.bedragOnderdelen)}
- Arbeid (PL + DM): ${formatAE(achterzijde.arbeidPlaatwerkAE + achterzijde.arbeidDemontageAE, true)} (${formatEuro(achterzijde.bedragPlaatwerk + achterzijde.bedragDemontage)})
- Subtotaal Netto: ${formatEuro(achterzijde.subtotaalNetto)}
- TOTAAL BRUTO (INCL BTW): ${formatEuro(achterzijde.totaalBruto)} (${achterzijde.percentageVanTotaal}%)

${overig.totaalBruto > 0 ? `3. OVERIG / ALGEMEEN:\n- TOTAAL BRUTO: ${formatEuro(overig.totaalBruto)} (${overig.percentageVanTotaal}%)\n\n` : ''}
GEZAMENLIJK TOTAALBEDRAG: ${formatEuro(totaal.totaalBruto)} (Netto: ${formatEuro(totaal.subtotaalNetto)})
Totale spuittijd: ${formatAE(totaal.spuittijdAE, true)}

SOLERA AUDATEX INVOERVOORSCHRIFT:
${soleraInfo.invoerTekst143}
Advies: ${soleraInfo.advies}

Gegenereerd via Audatex Schade Calculatie Splitter conform Solera AZT-richtlijnen.`;

    navigator.clipboard.writeText(text);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden">
      {/* Header with actions */}
      <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-slate-500" />
            <h3 className="font-bold text-slate-900 text-sm">
              Financieel Splitsingsrapport & Vergelijking
            </h3>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Uitsplitsing van spuittijd, AZT materiaalconstante en bedragen per sectie
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={handleCopyEmailSummary}
            className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-colors shadow-2xs"
            title="Kopieer samenvatting als tekst voor e-mail"
          >
            {copiedEmail ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
            {copiedEmail ? 'Gekopieerd' : 'Kopieer E-mail'}
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-colors shadow-2xs"
            title="Download CSV bestand"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            CSV Export
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 transition-colors shadow-2xs"
            title="Afdrukken via browser"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            Print
          </button>

          <button
            onClick={handleExportPdf}
            className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-700 text-white transition-colors shadow-2xs"
            title="Genereer en download officieel financieel rapport als PDF"
          >
            <FileDown className="w-3.5 h-3.5" />
            Exporteren als PDF
          </button>
        </div>
      </div>

      {/* Financial Comparison Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
            <tr>
              <th className="py-2.5 px-3.5">Kostenpost / Omschrijving</th>
              <th className="py-2.5 px-3.5 text-right text-blue-900 border-l border-slate-200 bg-blue-50/40">
                Voorzijde (Dossier A)
              </th>
              <th className="py-2.5 px-3.5 text-right text-indigo-900 border-l border-slate-200 bg-indigo-50/40">
                Achterzijde (Dossier B)
              </th>
              {overig.totaalBruto > 0 && (
                <th className="py-2.5 px-3.5 text-right text-slate-700 border-l border-slate-200">
                  Overig
                </th>
              )}
              <th className="py-2.5 px-3.5 text-right text-slate-900 font-bold border-l border-slate-200 bg-slate-100">
                Totaal Calculatie
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-mono text-slate-800">
            {/* SPUITTIJD & SPUITARBEID */}
            <tr className="hover:bg-slate-50/80 transition-colors">
              <td className="py-2.5 px-3.5 font-sans font-semibold text-slate-900 flex items-center gap-2">
                <span>Spuittijd (AE)</span>
                <span className="text-[10px] font-normal text-slate-500 font-mono">@{formatEuro(tarieven.spuittarief / 10)}/AE ({formatEuro(tarieven.spuittarief)}/u)</span>
              </td>
              <td className="py-2.5 px-3.5 text-right text-slate-900 font-bold border-l border-slate-200">
                {formatAE(voorzijde.spuittijdAE, true)} <span className="text-slate-500 font-normal">({formatEuro(voorzijde.bedragSpuitarbeid)})</span>
              </td>
              <td className="py-2.5 px-3.5 text-right text-slate-900 font-bold border-l border-slate-200">
                {formatAE(achterzijde.spuittijdAE, true)} <span className="text-slate-500 font-normal">({formatEuro(achterzijde.bedragSpuitarbeid)})</span>
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-3.5 text-right text-slate-800 border-l border-slate-200">
                  {formatAE(overig.spuittijdAE, true)} <span className="text-slate-500 font-normal">({formatEuro(overig.bedragSpuitarbeid)})</span>
                </td>
              )}
              <td className="py-2.5 px-3.5 text-right font-extrabold text-slate-900 border-l border-slate-200 bg-slate-50/60">
                {formatAE(totaal.spuittijdAE, true)} <span className="text-slate-500 font-normal">({formatEuro(totaal.bedragSpuitarbeid)})</span>
              </td>
            </tr>

            {/* PLAATWERK ARBEID */}
            <tr className="hover:bg-slate-50/80 transition-colors">
              <td className="py-2.5 px-4 font-sans text-slate-700">
                Plaatwerk arbeid (AE) <span className="text-[10px] text-slate-500 font-mono">@{formatEuro(tarieven.plaatwerktarief / 10)}/AE</span>
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatAE(voorzijde.arbeidPlaatwerkAE, true)} <span className="text-slate-500 font-normal">({formatEuro(voorzijde.bedragPlaatwerk)})</span>
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatAE(achterzijde.arbeidPlaatwerkAE, true)} <span className="text-slate-500 font-normal">({formatEuro(achterzijde.bedragPlaatwerk)})</span>
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                  {formatAE(overig.arbeidPlaatwerkAE, true)} <span className="text-slate-500">({formatEuro(overig.bedragPlaatwerk)})</span>
                </td>
              )}
              <td className="py-2.5 px-4 text-right font-semibold text-slate-900 border-l border-slate-200 bg-slate-50/60">
                {formatAE(totaal.arbeidPlaatwerkAE, true)} <span className="text-slate-500">({formatEuro(totaal.bedragPlaatwerk)})</span>
              </td>
            </tr>

            {/* DE/MONTAGE ARBEID */}
            <tr className="hover:bg-slate-50/80 transition-colors">
              <td className="py-2.5 px-4 font-sans text-slate-700">
                De/montage arbeid (AE) <span className="text-[10px] text-slate-500 font-mono">@{formatEuro(tarieven.demontagetarief / 10)}/AE</span>
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatAE(voorzijde.arbeidDemontageAE, true)} <span className="text-slate-500 font-normal">({formatEuro(voorzijde.bedragDemontage)})</span>
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatAE(achterzijde.arbeidDemontageAE, true)} <span className="text-slate-500 font-normal">({formatEuro(achterzijde.bedragDemontage)})</span>
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                  {formatAE(overig.arbeidDemontageAE, true)} <span className="text-slate-500">({formatEuro(overig.bedragDemontage)})</span>
                </td>
              )}
              <td className="py-2.5 px-4 text-right font-semibold text-slate-900 border-l border-slate-200 bg-slate-50/60">
                {formatAE(totaal.arbeidDemontageAE, true)} <span className="text-slate-500">({formatEuro(totaal.bedragDemontage)})</span>
              </td>
            </tr>

            {/* TOTAAL ARBEID SUBTOTAAL */}
            <tr className="bg-slate-50 font-bold text-slate-900 border-y border-slate-200">
              <td className="py-2.5 px-4 font-sans">
                Totaal Arbeidsloon ({formatAE(totaal.arbeidTotaalAE, true)})
              </td>
              <td className="py-2.5 px-4 text-right border-l border-slate-200 text-blue-900">
                {formatEuro(voorzijde.bedragTotaalArbeid)}
              </td>
              <td className="py-2.5 px-4 text-right border-l border-slate-200 text-indigo-900">
                {formatEuro(achterzijde.bedragTotaalArbeid)}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right border-l border-slate-200">
                  {formatEuro(overig.bedragTotaalArbeid)}
                </td>
              )}
              <td className="py-2.5 px-4 text-right border-l border-slate-200 font-extrabold text-slate-900 bg-slate-100">
                {formatEuro(totaal.bedragTotaalArbeid)}
              </td>
            </tr>

            {/* ONDERDELEN */}
            <tr className="hover:bg-slate-50/80 transition-colors">
              <td className="py-2.5 px-4 font-sans text-slate-700">
                Nieuwe Onderdelen
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatEuro(voorzijde.bedragOnderdelen)}
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatEuro(achterzijde.bedragOnderdelen)}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                  {formatEuro(overig.bedragOnderdelen)}
                </td>
              )}
              <td className="py-2.5 px-4 text-right font-semibold text-slate-900 border-l border-slate-200 bg-slate-50/60">
                {formatEuro(totaal.bedragOnderdelen)}
              </td>
            </tr>

            {/* SPUITMATERIAAL BASIS */}
            <tr className="hover:bg-slate-50/80 transition-colors">
              <td className="py-2.5 px-4 font-sans text-slate-700">
                Lakmateriaal basis (AZT formule)
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatEuro(voorzijde.bedragSpuitmateriaalBasis)}
              </td>
              <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                {formatEuro(achterzijde.bedragSpuitmateriaalBasis)}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                  {formatEuro(overig.bedragSpuitmateriaalBasis)}
                </td>
              )}
              <td className="py-2.5 px-4 text-right font-semibold text-slate-900 border-l border-slate-200 bg-slate-50/60">
                {formatEuro(totaal.bedragSpuitmateriaalBasis)}
              </td>
            </tr>

            {/* MATERIAALCONSTANTE (TZ 51 / 143) */}
            <tr className="bg-amber-50/40 hover:bg-amber-50/70 transition-colors border-y border-amber-200/50">
              <td className="py-2.5 px-4 font-sans font-semibold text-slate-900 flex items-center gap-2">
                <span>AZT Materiaalconstante (TZ 51)</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
                  Solera Richtlijn
                </span>
              </td>
              <td className="py-2.5 px-4 text-right text-slate-900 font-bold border-l border-slate-200">
                {formatEuro(voorzijde.bedragMateriaalconstante)}
              </td>
              <td className={`py-2.5 px-4 text-right font-bold border-l border-slate-200 ${
                achterzijde.bedragMateriaalconstante === 0 ? 'text-amber-700' : 'text-slate-900'
              }`}>
                {formatEuro(achterzijde.bedragMateriaalconstante)}
                {achterzijde.bedragMateriaalconstante === 0 && soleraInfo.constanteVoor > 0 && (
                  <span className="block text-[10px] font-normal text-amber-700">(-{formatEuro(soleraInfo.constanteVoor)} via TZ 143)</span>
                )}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right text-slate-800 border-l border-slate-200">
                  {formatEuro(overig.bedragMateriaalconstante)}
                </td>
              )}
              <td className="py-2.5 px-4 text-right font-bold text-slate-900 border-l border-slate-200 bg-amber-100/40">
                {formatEuro(totaal.bedragMateriaalconstante)}
              </td>
            </tr>

            {/* SPUITMATERIAAL TOTAAL */}
            <tr className="bg-slate-50 font-semibold text-slate-900">
              <td className="py-2.5 px-4 font-sans">
                Totaal Spuitmateriaal (Basis + Constante)
              </td>
              <td className="py-2.5 px-4 text-right border-l border-slate-200 text-slate-900">
                {formatEuro(voorzijde.bedragSpuitmateriaalTotaal)}
              </td>
              <td className="py-2.5 px-4 text-right border-l border-slate-200 text-slate-900">
                {formatEuro(achterzijde.bedragSpuitmateriaalTotaal)}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right border-l border-slate-200">
                  {formatEuro(overig.bedragSpuitmateriaalTotaal)}
                </td>
              )}
              <td className="py-2.5 px-4 text-right border-l border-slate-200 font-bold text-slate-900 bg-slate-100">
                {formatEuro(totaal.bedragSpuitmateriaalTotaal)}
              </td>
            </tr>

            {/* BIJKOMENDE KOSTEN */}
            {(totaal.bedragBijkomend ?? 0) > 0 && (
              <tr className="hover:bg-slate-50/80 transition-colors text-slate-700">
                <td className="py-2.5 px-4 font-sans text-slate-700">
                  Bijkomende kosten ({tarieven.bijkomendeKostenOmschrijving || 'Anti-roestbehandeling'})
                </td>
                <td className="py-2.5 px-4 text-right text-slate-700 border-l border-slate-200">
                  {(voorzijde.bedragBijkomend ?? 0) > 0 ? formatEuro(voorzijde.bedragBijkomend!) : '-'}
                </td>
                <td className="py-2.5 px-4 text-right text-slate-700 border-l border-slate-200 font-medium">
                  {(achterzijde.bedragBijkomend ?? 0) > 0 ? formatEuro(achterzijde.bedragBijkomend!) : '-'}
                </td>
                {overig.totaalBruto > 0 && (
                  <td className="py-2.5 px-4 text-right text-slate-700 border-l border-slate-200">
                    {(overig.bedragBijkomend ?? 0) > 0 ? formatEuro(overig.bedragBijkomend!) : '-'}
                  </td>
                )}
                <td className="py-2.5 px-4 text-right font-semibold text-slate-900 border-l border-slate-200 bg-slate-50/60">
                  {formatEuro(totaal.bedragBijkomend ?? 0)}
                </td>
              </tr>
            )}

            {/* DIVERSE KOSTEN */}
            <tr className="hover:bg-slate-50/80 transition-colors text-slate-700">
              <td className="py-2.5 px-4 font-sans text-slate-600">
                Klein materiaal ({tarieven.kleinMateriaalPerc}%) & Milieutoeslag
              </td>
              <td className="py-2.5 px-4 text-right text-slate-700 border-l border-slate-200">
                {formatEuro(voorzijde.bedragKleinMateriaal + voorzijde.bedragMilieu)}
              </td>
              <td className="py-2.5 px-4 text-right text-slate-700 border-l border-slate-200">
                {formatEuro(achterzijde.bedragKleinMateriaal + achterzijde.bedragMilieu)}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2.5 px-4 text-right text-slate-700 border-l border-slate-200">
                  {formatEuro(overig.bedragKleinMateriaal + overig.bedragMilieu)}
                </td>
              )}
              <td className="py-2.5 px-4 text-right text-slate-700 border-l border-slate-200 bg-slate-50/60">
                {formatEuro(totaal.bedragKleinMateriaal + totaal.bedragMilieu)}
              </td>
            </tr>

            {/* SUBTOTAAL NETTO */}
            <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-300">
              <td className="py-3 px-4 font-sans text-sm">
                SUBTOTAAL NETTO (Excl. BTW)
              </td>
              <td className="py-3 px-4 text-right border-l border-slate-200 text-blue-900 text-sm">
                {formatEuro(voorzijde.subtotaalNetto)}
              </td>
              <td className="py-3 px-4 text-right border-l border-slate-200 text-indigo-900 text-sm">
                {formatEuro(achterzijde.subtotaalNetto)}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-3 px-4 text-right border-l border-slate-200 text-slate-800">
                  {formatEuro(overig.subtotaalNetto)}
                </td>
              )}
              <td className="py-3 px-4 text-right border-l border-slate-200 font-extrabold text-slate-900 text-sm bg-slate-200/70">
                {formatEuro(totaal.subtotaalNetto)}
              </td>
            </tr>

            {/* BTW */}
            <tr className="hover:bg-slate-50/80 transition-colors text-slate-600">
              <td className="py-2 px-4 font-sans">
                BTW ({tarieven.btwPercentage}%)
              </td>
              <td className="py-2 px-4 text-right border-l border-slate-200">
                {formatEuro(voorzijde.btwBedrag)}
              </td>
              <td className="py-2 px-4 text-right border-l border-slate-200">
                {formatEuro(achterzijde.btwBedrag)}
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-2 px-4 text-right border-l border-slate-200">
                  {formatEuro(overig.btwBedrag)}
                </td>
              )}
              <td className="py-2 px-4 text-right border-l border-slate-200 bg-slate-50/60">
                {formatEuro(totaal.btwBedrag)}
              </td>
            </tr>

            {/* TOTAAL BRUTO */}
            <tr className="bg-slate-900 font-black text-white border-t border-b-2 border-slate-950">
              <td className="py-3.5 px-4 font-sans text-base">
                TOTAAL SCHADEBEDRAG (INCL. BTW)
              </td>
              <td className="py-3.5 px-4 text-right border-l border-slate-800 text-white text-base">
                <div>{formatEuro(voorzijde.totaalBruto)}</div>
                <div className="text-[11px] font-sans font-normal text-slate-300">({voorzijde.percentageVanTotaal}%)</div>
              </td>
              <td className="py-3.5 px-4 text-right border-l border-slate-800 text-white text-base">
                <div>{formatEuro(achterzijde.totaalBruto)}</div>
                <div className="text-[11px] font-sans font-normal text-slate-300">({achterzijde.percentageVanTotaal}%)</div>
              </td>
              {overig.totaalBruto > 0 && (
                <td className="py-3.5 px-4 text-right border-l border-slate-800 text-slate-200 text-sm">
                  <div>{formatEuro(overig.totaalBruto)}</div>
                  <div className="text-[11px] font-sans font-normal text-slate-300">({overig.percentageVanTotaal}%)</div>
                </td>
              )}
              <td className="py-3.5 px-4 text-right border-l border-slate-800 text-white text-base bg-black">
                <div>{formatEuro(totaal.totaalBruto)}</div>
                <div className="text-[11px] font-sans font-normal text-slate-300">100%</div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Solera Compliance Footer */}
      <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-600 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-slate-600">
          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
          <span>Calculatie berekend conform Solera Audatex AZT-normen en Tekstzone 143 richtlijnen (1 AE = 6 min • 10 AE = 1 uur).</span>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 text-slate-500">
          <span>Dossier: <span className="font-mono font-semibold text-slate-800">{meta.calculatienummer}</span></span>
          <span className="text-slate-300">•</span>
          <span className="font-semibold text-slate-700">Developed by Danny Radjkoemar</span>
        </div>
      </div>

      {/* DEDICATED PRINT TEMPLATE FOR WINDOW.PRINT() */}
      <div className="hidden print:block print:p-8 print:bg-white print:text-black">
        {/* Print Header */}
        <div className="border-b-2 border-black pb-4 mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-bold uppercase tracking-tight text-black">
                Solera Audatex Schadecalculatie
              </h1>
              <p className="text-sm font-semibold text-gray-700">
                Officiële Uitsplitsing Voor- en Achterzijde Schadedossier
              </p>
            </div>
            <div className="text-right">
              <div className="text-base font-bold text-black">{meta.kenteken}</div>
              <div className="text-xs text-gray-600">Calculatie: {meta.calculatienummer}</div>
              <div className="text-xs text-gray-600">Datum: {meta.datumCalculatie}</div>
            </div>
          </div>

          {/* Voertuig gegevens box */}
          <div className="mt-4 grid grid-cols-3 gap-2 text-xs border border-gray-300 p-2.5 rounded bg-gray-50">
            <div>
              <span className="text-gray-500 block">Voertuig:</span>
              <strong className="text-black">{meta.merkModel}</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Chassisnummer (VIN):</span>
              <span className="font-mono text-black">{meta.chassisnummer}</span>
            </div>
            <div>
              <span className="text-gray-500 block">Laksoort / Kleur:</span>
              <span className="text-black">{meta.laksoort} - {meta.kleurcode}</span>
            </div>
            <div>
              <span className="text-gray-500 block">Hersteller / Expert:</span>
              <span className="text-black">{meta.expertHersteller}</span>
            </div>
            <div>
              <span className="text-gray-500 block">Opdrachtgever:</span>
              <span className="text-black">{meta.opdrachtgever || 'Verzekering / Lease'}</span>
            </div>
            <div>
              <span className="text-gray-500 block">Dossiernummer:</span>
              <span className="font-mono text-black">{meta.dossiernummer}</span>
            </div>
          </div>
        </div>

        {/* Print Financial Table */}
        <h2 className="text-base font-bold mb-2 uppercase text-black">Financieel Splitsingsoverzicht</h2>
        <table className="w-full text-xs border-collapse border border-black mb-6">
          <thead>
            <tr className="bg-gray-200 border-b border-black">
              <th className="p-2 text-left border-r border-black">Kostenpost</th>
              <th className="p-2 text-right border-r border-black">Voorzijde (Dossier A)</th>
              <th className="p-2 text-right border-r border-black">Achterzijde (Dossier B)</th>
              <th className="p-2 text-right">Totaal Gecombineerd</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-gray-300">
              <td className="p-2 font-semibold">Spuittijd (AE)</td>
              <td className="p-2 text-right font-mono">{formatAE(voorzijde.spuittijdAE, true)}</td>
              <td className="p-2 text-right font-mono">{formatAE(achterzijde.spuittijdAE, true)}</td>
              <td className="p-2 text-right font-mono font-bold">{formatAE(totaal.spuittijdAE, true)}</td>
            </tr>
            <tr className="border-b border-gray-300">
              <td className="p-2">Spuitarbeid</td>
              <td className="p-2 text-right font-mono">{formatEuro(voorzijde.bedragSpuitarbeid)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(achterzijde.bedragSpuitarbeid)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(totaal.bedragSpuitarbeid)}</td>
            </tr>
            <tr className="border-b border-gray-300">
              <td className="p-2">Plaatwerk + De/montage Arbeid (AE)</td>
              <td className="p-2 text-right font-mono">{formatAE(voorzijde.arbeidPlaatwerkAE + voorzijde.arbeidDemontageAE, true)} ({formatEuro(voorzijde.bedragPlaatwerk + voorzijde.bedragDemontage)})</td>
              <td className="p-2 text-right font-mono">{formatAE(achterzijde.arbeidPlaatwerkAE + achterzijde.arbeidDemontageAE, true)} ({formatEuro(achterzijde.bedragPlaatwerk + achterzijde.bedragDemontage)})</td>
              <td className="p-2 text-right font-mono">{formatAE(totaal.arbeidPlaatwerkAE + totaal.arbeidDemontageAE, true)} ({formatEuro(totaal.bedragPlaatwerk + totaal.bedragDemontage)})</td>
            </tr>
            <tr className="border-b border-gray-300 bg-gray-50">
              <td className="p-2 font-semibold">Totaal Arbeid</td>
              <td className="p-2 text-right font-mono font-semibold">{formatEuro(voorzijde.bedragTotaalArbeid)}</td>
              <td className="p-2 text-right font-mono font-semibold">{formatEuro(achterzijde.bedragTotaalArbeid)}</td>
              <td className="p-2 text-right font-mono font-bold">{formatEuro(totaal.bedragTotaalArbeid)}</td>
            </tr>
            <tr className="border-b border-gray-300">
              <td className="p-2">Nieuwe Onderdelen</td>
              <td className="p-2 text-right font-mono">{formatEuro(voorzijde.bedragOnderdelen)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(achterzijde.bedragOnderdelen)}</td>
              <td className="p-2 text-right font-mono font-semibold">{formatEuro(totaal.bedragOnderdelen)}</td>
            </tr>
            <tr className="border-b border-gray-300">
              <td className="p-2">AZT Materiaalconstante (Tekstzone 51/143)</td>
              <td className="p-2 text-right font-mono">{formatEuro(voorzijde.bedragMateriaalconstante)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(achterzijde.bedragMateriaalconstante)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(totaal.bedragMateriaalconstante)}</td>
            </tr>
            <tr className="border-b border-gray-300">
              <td className="p-2">Lakmateriaal Basis</td>
              <td className="p-2 text-right font-mono">{formatEuro(voorzijde.bedragSpuitmateriaalBasis)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(achterzijde.bedragSpuitmateriaalBasis)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(totaal.bedragSpuitmateriaalBasis)}</td>
            </tr>
            <tr className="border-b border-gray-300 bg-gray-50">
              <td className="p-2 font-semibold">Totaal Spuitmateriaal</td>
              <td className="p-2 text-right font-mono font-semibold">{formatEuro(voorzijde.bedragSpuitmateriaalTotaal)}</td>
              <td className="p-2 text-right font-mono font-semibold">{formatEuro(achterzijde.bedragSpuitmateriaalTotaal)}</td>
              <td className="p-2 text-right font-mono font-bold">{formatEuro(totaal.bedragSpuitmateriaalTotaal)}</td>
            </tr>
            {(totaal.bedragBijkomend ?? 0) > 0 && (
              <tr className="border-b border-gray-300">
                <td className="p-2">Bijkomende kosten ({tarieven.bijkomendeKostenOmschrijving || 'Anti-roestbehandeling'})</td>
                <td className="p-2 text-right font-mono">{(voorzijde.bedragBijkomend ?? 0) > 0 ? formatEuro(voorzijde.bedragBijkomend!) : '-'}</td>
                <td className="p-2 text-right font-mono">{(achterzijde.bedragBijkomend ?? 0) > 0 ? formatEuro(achterzijde.bedragBijkomend!) : '-'}</td>
                <td className="p-2 text-right font-mono">{formatEuro(totaal.bedragBijkomend ?? 0)}</td>
              </tr>
            )}
            <tr className="border-b border-gray-300">
              <td className="p-2">Klein Materiaal & Milieutoeslag</td>
              <td className="p-2 text-right font-mono">{formatEuro(voorzijde.bedragKleinMateriaal + voorzijde.bedragMilieu)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(achterzijde.bedragKleinMateriaal + achterzijde.bedragMilieu)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(totaal.bedragKleinMateriaal + totaal.bedragMilieu)}</td>
            </tr>
            <tr className="border-b-2 border-black bg-gray-100 font-bold">
              <td className="p-2 text-sm">SUBTOTAAL NETTO (Excl. BTW)</td>
              <td className="p-2 text-right font-mono text-sm">{formatEuro(voorzijde.subtotaalNetto)}</td>
              <td className="p-2 text-right font-mono text-sm">{formatEuro(achterzijde.subtotaalNetto)}</td>
              <td className="p-2 text-right font-mono text-sm">{formatEuro(totaal.subtotaalNetto)}</td>
            </tr>
            <tr className="border-b border-gray-300">
              <td className="p-2">BTW (21%)</td>
              <td className="p-2 text-right font-mono">{formatEuro(voorzijde.btwBedrag)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(achterzijde.btwBedrag)}</td>
              <td className="p-2 text-right font-mono">{formatEuro(totaal.btwBedrag)}</td>
            </tr>
            <tr className="bg-gray-200 font-black text-sm">
              <td className="p-2.5">TOTAAL SCHADEBEDRAG (INCL. BTW)</td>
              <td className="p-2.5 text-right font-mono">{formatEuro(voorzijde.totaalBruto)} ({voorzijde.percentageVanTotaal}%)</td>
              <td className="p-2.5 text-right font-mono">{formatEuro(achterzijde.totaalBruto)} ({achterzijde.percentageVanTotaal}%)</td>
              <td className="p-2.5 text-right font-mono text-base">{formatEuro(totaal.totaalBruto)} (100%)</td>
            </tr>
          </tbody>
        </table>

        {/* Solera Richtlijn vermelding op print */}
        <div className="p-3 border border-black rounded bg-gray-50 text-xs mb-8">
          <strong className="block mb-1">Solera Audatex Kennisbank Verantwoording:</strong>
          <p className="mb-1">{soleraInfo.advies}</p>
          <div className="font-mono bg-white p-1.5 border border-gray-300 rounded text-[11px]">
            {soleraInfo.invoerTekst143}
          </div>
        </div>

        {/* Handtekeningen blok */}
        <div className="grid grid-cols-2 gap-8 text-xs pt-8 border-t border-gray-400">
          <div>
            <span className="block text-gray-600 mb-12">Voor akkoord Schadehersteller / Calculateur:</span>
            <div className="border-b border-black w-48 mb-1"></div>
            <span>Datum: .......................................</span>
          </div>
          <div>
            <span className="block text-gray-600 mb-12">Voor akkoord Schade-expert / Verzekeraar:</span>
            <div className="border-b border-black w-48 mb-1"></div>
            <span>Datum: .......................................</span>
          </div>
        </div>

        {/* Print Colofon */}
        <div className="mt-8 pt-3 border-t border-gray-300 text-[10px] text-gray-500 flex justify-between items-center">
          <span>Solera Audatex Schadecalculatie Splitter (1 AE = 6 min • 10 AE = 1 uur)</span>
          <span className="font-semibold text-gray-700">Developed by Danny Radjkoemar</span>
        </div>
      </div>
    </div>
  );
};
