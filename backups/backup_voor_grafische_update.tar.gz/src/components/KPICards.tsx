import React from 'react';
import { SectieTotalen } from '../types/audatex';
import { formatEuro, formatUren, formatAE } from '../utils/calculator';
import { Paintbrush, Wrench, Package, Layers, TrendingUp, Tag, Clock } from 'lucide-react';

interface KPICardsProps {
  voorzijde: SectieTotalen;
  achterzijde: SectieTotalen;
  overig: SectieTotalen;
  totaal: SectieTotalen;
}

export const KPICards: React.FC<KPICardsProps> = ({
  voorzijde,
  achterzijde,
  overig,
  totaal
}) => {
  return (
    <div className="space-y-3">
      {/* Visual split progress bar - Clean & utilitarian white style */}
      <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between text-xs font-medium text-slate-700 mb-2 gap-2">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-xs bg-blue-600"></span>
              <span>Voorzijde (Dossier A): <strong className="text-slate-900 font-bold">{voorzijde.percentageVanTotaal}%</strong> ({formatEuro(voorzijde.totaalBruto)})</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-xs bg-indigo-600"></span>
              <span>Achterzijde (Dossier B): <strong className="text-slate-900 font-bold">{achterzijde.percentageVanTotaal}%</strong> ({formatEuro(achterzijde.totaalBruto)})</span>
            </div>
            {overig.totaalBruto > 0 && (
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-xs bg-slate-400"></span>
                <span>Overig: <strong className="text-slate-900 font-bold">{overig.percentageVanTotaal}%</strong> ({formatEuro(overig.totaalBruto)})</span>
              </div>
            )}
          </div>
          <div className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 flex items-center gap-1.5">
            <Clock className="w-3 h-3 text-blue-600" />
            <span>Audatex norm: 1 AE = 6 min • 10 AE = 1 uur</span>
          </div>
        </div>

        <div className="h-2.5 w-full bg-slate-100 rounded-sm overflow-hidden flex border border-slate-200">
          <div 
            className="bg-blue-600 transition-all duration-300"
            style={{ width: `${voorzijde.percentageVanTotaal}%` }}
            title={`Voorzijde: ${voorzijde.percentageVanTotaal}%`}
          />
          <div 
            className="bg-indigo-600 transition-all duration-300"
            style={{ width: `${achterzijde.percentageVanTotaal}%` }}
            title={`Achterzijde: ${achterzijde.percentageVanTotaal}%`}
          />
          {overig.percentageVanTotaal > 0 && (
            <div 
              className="bg-slate-400 transition-all duration-300"
              style={{ width: `${overig.percentageVanTotaal}%` }}
              title={`Overig: ${overig.percentageVanTotaal}%`}
            />
          )}
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        {/* VOORZIJDE CARD */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 text-slate-800 shadow-xs border-t-4 border-t-blue-600">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
              Voorzijde (Dossier A)
            </span>
            <span className="text-xs text-slate-500 font-mono">
              {voorzijde.itemsCount} bewerkingen
            </span>
          </div>

          <div className="mb-3">
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatEuro(voorzijde.totaalBruto)}
            </div>
            <div className="text-xs text-slate-500 mt-0.5 font-mono">
              Netto: {formatEuro(voorzijde.subtotaalNetto)} • BTW: {formatEuro(voorzijde.btwBedrag)}
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            {/* Spuittijd in AE */}
            <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-700">
                <Paintbrush className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-900">Spuittijd (AE)</div>
                  <div className="text-[10px] text-slate-500 font-mono">Arbeid: {formatEuro(voorzijde.bedragSpuitarbeid)}</div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-extrabold text-sm text-slate-900 font-mono block">
                  {formatAE(voorzijde.spuittijdAE)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {formatUren(voorzijde.spuittijdUren)}
                </span>
              </div>
            </div>

            {/* Materiaalconstante */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                AZT Materiaalconstante:
              </span>
              <span className="font-bold text-slate-900 font-mono">
                {formatEuro(voorzijde.bedragMateriaalconstante)}
              </span>
            </div>

            {/* Lakmateriaal totaal */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-slate-400" />
                Lakmateriaal totaal:
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatEuro(voorzijde.bedragSpuitmateriaalTotaal)}
              </span>
            </div>

            {/* Onderdelen */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-slate-400" />
                Nieuwe Onderdelen:
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatEuro(voorzijde.bedragOnderdelen)}
              </span>
            </div>

            {/* Arbeid totaal */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-slate-400" />
                Arbeid (PL + DM):
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatAE(voorzijde.arbeidPlaatwerkAE + voorzijde.arbeidDemontageAE, true)} ({formatEuro(voorzijde.bedragPlaatwerk + voorzijde.bedragDemontage)})
              </span>
            </div>
          </div>
        </div>

        {/* ACHTERZIJDE CARD */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 text-slate-800 shadow-xs border-t-4 border-t-indigo-600">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
              Achterzijde (Dossier B)
            </span>
            <span className="text-xs text-slate-500 font-mono">
              {achterzijde.itemsCount} bewerkingen
            </span>
          </div>

          <div className="mb-3">
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatEuro(achterzijde.totaalBruto)}
            </div>
            <div className="text-xs text-slate-500 mt-0.5 font-mono">
              Netto: {formatEuro(achterzijde.subtotaalNetto)} • BTW: {formatEuro(achterzijde.btwBedrag)}
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            {/* Spuittijd in AE */}
            <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-700">
                <Paintbrush className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-900">Spuittijd (AE)</div>
                  <div className="text-[10px] text-slate-500 font-mono">Arbeid: {formatEuro(achterzijde.bedragSpuitarbeid)}</div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-extrabold text-sm text-slate-900 font-mono block">
                  {formatAE(achterzijde.spuittijdAE)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {formatUren(achterzijde.spuittijdUren)}
                </span>
              </div>
            </div>

            {/* Materiaalconstante */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                AZT Materiaalconstante:
              </span>
              <span className={`font-semibold font-mono ${achterzijde.bedragMateriaalconstante === 0 ? 'text-amber-700 font-bold' : 'text-slate-900'}`}>
                {formatEuro(achterzijde.bedragMateriaalconstante)}
                {achterzijde.bedragMateriaalconstante === 0 && ' (TZ 143)'}
              </span>
            </div>

            {/* Lakmateriaal totaal */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-slate-400" />
                Lakmateriaal totaal:
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatEuro(achterzijde.bedragSpuitmateriaalTotaal)}
              </span>
            </div>

            {/* Onderdelen */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-slate-400" />
                Nieuwe Onderdelen:
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatEuro(achterzijde.bedragOnderdelen)}
              </span>
            </div>

            {/* Arbeid totaal */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-slate-400" />
                Arbeid (PL + DM):
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatAE(achterzijde.arbeidPlaatwerkAE + achterzijde.arbeidDemontageAE, true)} ({formatEuro(achterzijde.bedragPlaatwerk + achterzijde.bedragDemontage)})
              </span>
            </div>
          </div>
        </div>

        {/* GEZAMENLIJK TOTAAL CARD */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 text-slate-800 shadow-xs border-t-4 border-t-slate-800">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-slate-600" />
              Totale Calculatie
            </span>
            <span className="text-xs text-slate-500 font-mono">
              {totaal.itemsCount} posities
            </span>
          </div>

          <div className="mb-3">
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatEuro(totaal.totaalBruto)}
            </div>
            <div className="text-xs text-slate-500 mt-0.5 font-mono">
              Netto: {formatEuro(totaal.subtotaalNetto)} • BTW: {formatEuro(totaal.btwBedrag)}
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            {/* Totale Spuittijd */}
            <div className="p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-700">
                <Paintbrush className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-900">Totale Spuittijd (AE)</div>
                  <div className="text-[10px] text-slate-500 font-mono">Arbeid: {formatEuro(totaal.bedragSpuitarbeid)}</div>
                </div>
              </div>
              <div className="text-right">
                <span className="font-extrabold text-sm text-slate-900 font-mono block">
                  {formatAE(totaal.spuittijdAE)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {formatUren(totaal.spuittijdUren)}
                </span>
              </div>
            </div>

            {/* Materiaalconstante totaal */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                AZT Materiaalconstante (TZ 51):
              </span>
              <span className="font-bold text-slate-900 font-mono">
                {formatEuro(totaal.bedragMateriaalconstante)}
              </span>
            </div>

            {/* Lakmateriaal totaal */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-slate-400" />
                Totaal Lakmateriaal:
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatEuro(totaal.bedragSpuitmateriaalTotaal)}
              </span>
            </div>

            {/* Totale Onderdelen */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-slate-400" />
                Totaal Onderdelen:
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatEuro(totaal.bedragOnderdelen)}
              </span>
            </div>

            {/* Totale Arbeid */}
            <div className="flex items-center justify-between py-0.5 text-slate-700">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Wrench className="w-3.5 h-3.5 text-slate-400" />
                Totaal Arbeid:
              </span>
              <span className="font-semibold text-slate-800 font-mono">
                {formatAE(totaal.arbeidTotaalAE, true)} ({formatEuro(totaal.bedragTotaalArbeid)})
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
