import React, { useState } from 'react';
import { RdwVoertuigData } from '../types/audatex';
import { formatEuro } from '../utils/calculator';
import { 
  ShieldCheck, 
  AlertTriangle, 
  TrendingDown, 
  Calendar, 
  Fuel, 
  CheckCircle2, 
  Info, 
  Search, 
  RefreshCw,
  Gauge
} from 'lucide-react';

interface RdwDagwaardeCardProps {
  rdw?: RdwVoertuigData;
  totaalSchadeBruto: number;
  kenteken: string;
  onRefreshRdw: (newKenteken: string) => Promise<void>;
  isLoading?: boolean;
}

export const RdwDagwaardeCard: React.FC<RdwDagwaardeCardProps> = ({
  rdw,
  totaalSchadeBruto,
  kenteken,
  onRefreshRdw,
  isLoading = false
}) => {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [customPlate, setCustomPlate] = useState(kenteken);
  const [showPlateInput, setShowPlateInput] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await onRefreshRdw(customPlate || kenteken);
      setShowPlateInput(false);
    } finally {
      setIsRefreshing(false);
    }
  };

  const dagwaarde = rdw?.indicatieveDagwaarde?.geschat || 0;
  const catalogusprijs = rdw?.catalogusprijs || 0;
  
  // Berekening ratio schade t.o.v. dagwaarde
  const schadePercentage = dagwaarde > 0 ? (totaalSchadeBruto / dagwaarde) * 100 : 0;
  
  // Economisch Totaal Verlies drempel in Nederland (gewoonlijk rond 67% tot 75% van de dagwaarde minus wrakwaarde)
  const isEconomischTotalLoss = schadePercentage >= 67;
  const isAandacht = schadePercentage >= 50 && schadePercentage < 67;

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-xs overflow-hidden no-print">
      {/* Background RDW loading indicator banner */}
      {(isLoading || isRefreshing) && (
        <div className="bg-blue-50 border-b border-blue-200 px-4 py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 text-xs text-blue-900">
          <div className="flex items-center gap-2">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600 shrink-0" />
            <span>
              RDW-voertuiggegevens en dagwaarde worden op de achtergrond geladen voor kenteken <strong className="font-mono">{kenteken}</strong>...
            </span>
          </div>
          <span className="text-[10px] text-blue-700 font-semibold bg-white px-2 py-0.5 rounded border border-blue-200 w-fit">
            Calculatieresultaten zijn direct beschikbaar
          </span>
        </div>
      )}

      {/* Top Header Bar */}
      <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-bold text-xs">
            NL
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
              RDW Voertuiggegevens & Indicatieve Dagwaarde
              {rdw?.gevonden && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3" />
                  RDW Geverifieerd
                </span>
              )}
            </h3>
            <p className="text-[11px] text-slate-500">
              Officiële RDW-specificaties en economische haalbaarheidstoetsing t.o.v. de herstelkosten
            </p>
          </div>
        </div>

        {/* Kenteken aanpassen / herladen */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          {showPlateInput ? (
            <div className="flex items-center gap-1.5 animate-fadeIn">
              <input
                type="text"
                value={customPlate}
                onChange={(e) => setCustomPlate(e.target.value.toUpperCase())}
                placeholder="Kenteken..."
                className="w-24 px-2 py-1 text-xs font-mono font-bold uppercase bg-white border border-slate-300 rounded focus:outline-none focus:border-blue-600"
              />
              <button
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="px-2.5 py-1 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors disabled:opacity-50"
              >
                {isRefreshing ? 'Laden...' : 'Zoek'}
              </button>
              <button
                onClick={() => setShowPlateInput(false)}
                className="text-xs text-slate-500 hover:text-slate-800 px-1"
              >
                Annuleer
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowPlateInput(true)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-300 rounded transition-colors shadow-2xs"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>Kenteken wijzigen/ophalen</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Left RDW Specs, Right Dagwaarde vs Schade */}
      <div className="p-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Kolom 1 (7 cols): Voertuig Specificaties */}
        <div className="lg:col-span-7 space-y-3">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="p-2.5 rounded bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">Merk & Model</span>
              <span className={`font-bold truncate block ${isLoading && !rdw?.merk ? 'text-blue-600 animate-pulse' : 'text-slate-900'}`}>
                {rdw?.merk ? `${rdw.merk} ${rdw.handelsbenaming || ''}` : (isLoading ? 'RDW ophalen...' : 'Onbekend')}
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">Eerste toelating</span>
              <span className="font-semibold text-slate-800 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-400" />
                {rdw?.datumEersteToelating || (isLoading ? 'Ophalen...' : 'Onbekend')}
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">Brandstof</span>
              <span className="font-semibold text-slate-800 flex items-center gap-1">
                <Fuel className="w-3 h-3 text-slate-400" />
                {rdw?.brandstof || (isLoading ? 'Ophalen...' : 'Benzine / Diesel')}
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">APK Vervaldatum</span>
              <span className={`font-semibold flex items-center gap-1 ${rdw?.apkGeldig ? 'text-slate-800' : rdw ? 'text-red-700 font-bold' : 'text-slate-700'}`}>
                {rdw?.vervaldatumApk || (isLoading ? 'Ophalen...' : 'Niet bekend')}
                {rdw?.apkGeldig === false && <span className="text-[10px] text-red-600">(Verlopen)</span>}
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">Kleur & Inrichting</span>
              <span className="font-medium text-slate-700 capitalize truncate block">
                {rdw?.eersteKleur || 'Standaard'} • {rdw?.inrichting || (isLoading ? 'Ophalen...' : 'Personenauto')}
              </span>
            </div>

            <div className="p-2.5 rounded bg-slate-50 border border-slate-200/80">
              <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-0.5">Catalogusprijs (nieuw)</span>
              <span className="font-bold text-slate-900 font-mono">
                {catalogusprijs > 0 ? formatEuro(catalogusprijs) : (isLoading ? 'Ophalen...' : 'Niet geregistreerd')}
              </span>
            </div>
          </div>

          {/* RDW status footer note */}
          <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
            <span className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full ${rdw?.wamVerzekerd ? 'bg-emerald-500' : 'bg-slate-400'}`} />
              WAM Verzekerd: <strong className="text-slate-700 font-medium">{rdw?.wamVerzekerd ? 'Ja' : (isLoading ? 'Controle...' : 'Onbekend')}</strong>
            </span>
            <span>•</span>
            <span>
              Massa rijklaar: <strong className="text-slate-700 font-medium">{rdw?.massaLedigVoertuig ? `${rdw.massaLedigVoertuig} kg` : (isLoading ? '...' : '-')}</strong>
            </span>
          </div>
        </div>

        {/* Kolom 2 (5 cols): Dagwaarde & Economische Toetsing */}
        <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-md p-3.5 flex flex-col justify-between space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                INDICATIEVE DAGWAARDE
              </span>
              <span className="text-[10px] font-mono text-slate-500">
                {rdw?.indicatieveDagwaarde?.leeftijdInMaanden ? `${rdw.indicatieveDagwaarde.leeftijdInMaanden} mnd oud` : ''}
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className={`font-extrabold font-mono tracking-tight ${
                dagwaarde > 0 ? 'text-2xl sm:text-3xl text-slate-900' : isLoading ? 'text-lg text-blue-600 animate-pulse' : 'text-2xl sm:text-3xl text-slate-900'
              }`}>
                {dagwaarde > 0 ? formatEuro(dagwaarde) : (isLoading ? 'RDW ophalen...' : 'N.t.b.')}
              </span>
              {rdw?.indicatieveDagwaarde?.laag && rdw?.indicatieveDagwaarde?.hoog && (
                <span className="text-xs text-slate-500 font-mono">
                  (bandbreedte {formatEuro(rdw.indicatieveDagwaarde.laag)} - {formatEuro(rdw.indicatieveDagwaarde.hoog)})
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-500 mt-1 leading-tight">
              {rdw?.indicatieveDagwaarde?.methode || (isLoading ? 'RDW-dagwaarde wordt op de achtergrond berekend...' : 'Berekend o.b.v. Bovag/NIVRE afschrijving en cataloguswaarde')}
            </p>
          </div>

          {/* Economische vergelijking: Schade t.o.v. Dagwaarde */}
          <div className="pt-2.5 border-t border-slate-200/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-600">Herstelkosten t.o.v. Dagwaarde:</span>
              <span className={`font-mono text-sm font-bold ${
                isEconomischTotalLoss ? 'text-red-700' : isAandacht ? 'text-amber-700' : 'text-emerald-700'
              }`}>
                {schadePercentage.toFixed(1)}%
              </span>
            </div>

            {/* Voortgangsbalk */}
            <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden flex">
              <div 
                className={`h-full transition-all duration-500 ${
                  isEconomischTotalLoss 
                    ? 'bg-red-600' 
                    : isAandacht 
                    ? 'bg-amber-500' 
                    : 'bg-emerald-600'
                }`}
                style={{ width: `${Math.min(100, Math.max(5, schadePercentage))}%` }}
              />
            </div>

            {/* Expertise advies */}
            <div className={`p-2 rounded text-[11px] flex items-start gap-1.5 ${
              isEconomischTotalLoss
                ? 'bg-red-50 text-red-900 border border-red-200'
                : isAandacht
                ? 'bg-amber-50 text-amber-900 border border-amber-200'
                : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
            }`}>
              {isEconomischTotalLoss ? (
                <>
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-bold">Aandacht Expert:</strong> Herstelbedrag ({formatEuro(totaalSchadeBruto)}) overschrijdt 67% van de dagwaarde. Risico op economisch totaal verlies.
                  </div>
                </>
              ) : isAandacht ? (
                <>
                  <Info className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-bold">Grensgebied:</strong> Schade bedraagt tussen 50% en 67% van de dagwaarde. Controleer de restwaarde (wrakwaarde).
                  </div>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-bold">Economisch herstelbaar:</strong> Schade ({formatEuro(totaalSchadeBruto)}) bedraagt {schadePercentage.toFixed(1)}% van de dagwaarde en blijft ruim onder de 67% drempel.
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
