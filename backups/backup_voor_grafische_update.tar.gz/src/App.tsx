/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { AnalyseResultaat, MateriaalconstanteMethode, Tarieven, DossierMeta, CalculatieRegel } from './types/audatex';
import { berekenSectieTotalen, formatEuro } from './utils/calculator';
import { lookupRdwVehicle } from './utils/rdwService';
import { DossierHeader } from './components/DossierHeader';
import { RdwDagwaardeCard } from './components/RdwDagwaardeCard';
import { KPICards } from './components/KPICards';
import { SoleraConfig } from './components/SoleraConfig';
import { CalculatieTabel } from './components/CalculatieTabel';
import { FinancieelRapport } from './components/FinancieelRapport';
import { InputSection } from './components/InputSection';
import { SoleraInfoModal } from './components/SoleraInfoModal';
import { AftrekCalculator } from './components/AftrekCalculator';
import { AztNaslag } from './components/AztNaslag';
import { AppLogo } from './components/AppLogo';
import { 
  HelpCircle, 
  Printer, 
  PlusCircle, 
  ShieldCheck, 
  Sliders, 
  Calculator, 
  BookOpen, 
  Split,
  Download,
  Loader2
} from 'lucide-react';

type MainTab = 'splitser' | 'calculator' | 'naslag';
type SubView = 'report' | 'table' | 'aftrek';

export default function App() {
  const [data, setData] = useState<AnalyseResultaat | null>(null);
  const [methode, setMethode] = useState<MateriaalconstanteMethode>('solera_tz143');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRdwLoading, setIsRdwLoading] = useState<boolean>(false);
  const [isHtmlDownloading, setIsHtmlDownloading] = useState<boolean>(false);
  const [isKnowledgeBaseOpen, setIsKnowledgeBaseOpen] = useState<boolean>(false);
  const [mainTab, setMainTab] = useState<MainTab>('splitser');
  const [activeSubView, setActiveSubView] = useState<SubView>('report');
  const [showConfig, setShowConfig] = useState<boolean>(false);

  const isStandaloneHtml =
    (typeof __IS_STANDALONE_HTML__ !== 'undefined' && __IS_STANDALONE_HTML__) ||
    (typeof window !== 'undefined' && window.location.protocol === 'file:');

  // Live calculation of all section totals
  const totalen = useMemo(() => {
    if (!data) return null;
    return berekenSectieTotalen(data.regels, data.tarieven, methode, data.audatexEindcalculatie);
  }, [data, methode]);

  const handleUpdateRegels = (newRegels: CalculatieRegel[]) => {
    if (!data) return;
    setData({
      ...data,
      regels: newRegels
    });
  };

  const handleUpdateTarieven = (newTarieven: Tarieven) => {
    if (!data) return;
    setData({
      ...data,
      tarieven: newTarieven
    });
  };

  const handleUpdateMeta = (newMeta: DossierMeta) => {
    if (!data) return;
    setData({
      ...data,
      meta: newMeta
    });
  };

  const fetchRdwWithFallback = async (cleanPlate: string) => {
    if (window.location.protocol === 'file:') {
      return lookupRdwVehicle(cleanPlate);
    }
    try {
      const res = await fetch(`/api/rdw/${encodeURIComponent(cleanPlate)}`);
      if (res.ok) {
        return await res.json();
      }
      return null;
    } catch {
      return lookupRdwVehicle(cleanPlate);
    }
  };

  const handleLoadData = (newData: AnalyseResultaat) => {
    // 1. Directe weergave van de calculatie (geen vertraging)
    setData(newData);
    if (newData.materiaalconstanteMethode) {
      setMethode(newData.materiaalconstanteMethode);
    }
    setMainTab('splitser');

    // 2. RDW-gegevens en dagwaarde direct asynchroon op de achtergrond ophalen
    const plate = newData.meta?.kenteken;
    if (plate && plate !== 'ONBEKEND') {
      const cleanPlate = plate.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
      if (cleanPlate.length >= 5 && cleanPlate.length <= 8) {
        setIsRdwLoading(true);
        fetchRdwWithFallback(cleanPlate)
          .then((rdwData) => {
            if (rdwData) {
              setData(prev => {
                if (!prev) return prev;
                return {
                  ...prev,
                  meta: {
                    ...prev.meta,
                    kenteken: rdwData.geformatteerdKenteken || prev.meta.kenteken,
                    merkModel: rdwData.merk && rdwData.handelsbenaming 
                      ? `${rdwData.merk} ${rdwData.handelsbenaming}` 
                      : prev.meta.merkModel
                  },
                  rdw: rdwData
                };
              });
            }
          })
          .catch(err => {
            console.warn('Achtergrond RDW-koppeling overgeslagen:', err);
          })
          .finally(() => {
            setIsRdwLoading(false);
          });
      }
    }
  };

  const handleNewCalculation = () => {
    setData(null);
    setMainTab('splitser');
  };

  const handleDownloadHtmlApp = async () => {
    if (isHtmlDownloading) return;
    setIsHtmlDownloading(true);
    try {
      if (window.location.protocol === 'file:') {
        const clone = document.documentElement.cloneNode(true) as HTMLElement;
        const clonedRoot = clone.querySelector('#root');
        if (clonedRoot) clonedRoot.innerHTML = '';
        const htmlContent = '<!doctype html>\n' + clone.outerHTML;
        const blob = new Blob([htmlContent], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Audatex-Schade-Splitter.html';
        a.rel = 'noopener';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 60000);
        return;
      }

      const prepRes = await fetch('/api/download-html?prepare=1');
      if (!prepRes.ok) {
        throw new Error('Kon standalone HTML-bestand niet voorbereiden.');
      }

      const res = await fetch('/api/download-html');
      if (!res.ok) {
        throw new Error('Kon standalone HTML-bestand niet genereren.');
      }
      const buffer = await res.arrayBuffer();
      const blob = new Blob([buffer], { type: 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Audatex-Schade-Splitter.html';
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (err) {
      console.error('Fout bij downloaden HTML-app:', err);
    } finally {
      setIsHtmlDownloading(false);
    }
  };

  // Live RDW lookup for manual plate update or refresh
  const handleLookupPlate = async (kenteken: string) => {
    if (!kenteken) return;
    const cleanPlate = kenteken.trim().toUpperCase();
    setIsRdwLoading(true);
    try {
      const rdwData = await fetchRdwWithFallback(cleanPlate);
      if (rdwData) {
        setData(prev => {
          if (!prev) return prev;
          return {
            ...prev,
            meta: {
              ...prev.meta,
              kenteken: rdwData.geformatteerdKenteken || cleanPlate,
              merkModel: rdwData.merk && rdwData.handelsbenaming 
                ? `${rdwData.merk} ${rdwData.handelsbenaming}` 
                : prev.meta.merkModel
            },
            rdw: rdwData
          };
        });
      } else {
        setData(prev => {
          if (!prev) return prev;
          return {
            ...prev,
            meta: {
              ...prev.meta,
              kenteken: cleanPlate
            }
          };
        });
      }
    } catch (e) {
      console.error('Fout bij opvragen RDW:', e);
    } finally {
      setIsRdwLoading(false);
    }
  };

  // Derive initial values for AftrekCalculator if data is present
  const calculatorInitialSchade1 = useMemo(() => {
    if (!totalen) return undefined;
    return {
      naam: 'Schade 1 (Voorzijde)',
      materiaalsoort: 'metaal' as const,
      situatie: 'aan_voertuig_zonder_voorspuiten' as const,
      voorbereidingstijdAE: totalen.voorzijde.spuittijdAE || Math.round(totalen.voorzijde.spuittijdUren * 10),
      materiaalconstante: totalen.voorzijde.bedragMateriaalconstante
    };
  }, [totalen]);

  const calculatorInitialSchade2 = useMemo(() => {
    if (!totalen) return undefined;
    return {
      naam: 'Schade 2 (Achterzijde)',
      materiaalsoort: 'kunststof' as const,
      situatie: 'uitgebouwd' as const,
      voorbereidingstijdAE: totalen.achterzijde.spuittijdAE || Math.round(totalen.achterzijde.spuittijdUren * 10),
      materiaalconstante: totalen.achterzijde.bedragMateriaalconstante
    };
  }, [totalen]);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans">
      {/* Top Navbar - Clean White Business Layout */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-2xs no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-4">
          {/* Logo & title */}
          <div className="flex items-center gap-2.5">
            <AppLogo />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
                  Audatex Schade Calculatie Splitter
                </h1>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-300 font-semibold">
                  Solera AZT
                </span>
              </div>
            </div>
          </div>

          {/* Center Main Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-md border border-slate-200 text-xs">
            <button
              onClick={() => setMainTab('splitser')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-colors ${
                mainTab === 'splitser'
                  ? 'bg-white text-slate-900 font-bold shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Split className="w-3.5 h-3.5 text-blue-600" />
              <span>Calculatie Splitsen</span>
            </button>

            <button
              onClick={() => setMainTab('calculator')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-colors ${
                mainTab === 'calculator'
                  ? 'bg-white text-slate-900 font-bold shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calculator className="w-3.5 h-3.5 text-slate-600" />
              <span>Zelf Rekenen (Aftrekcheck)</span>
            </button>

            <button
              onClick={() => setMainTab('naslag')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-colors ${
                mainTab === 'naslag'
                  ? 'bg-white text-slate-900 font-bold shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-slate-600" />
              <span>Naslag AZT</span>
            </button>
          </nav>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            {data && mainTab === 'splitser' && (
              <>
                <button
                  onClick={handleNewCalculation}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 transition-colors shadow-2xs"
                  title="Upload een nieuwe calculatie"
                >
                  <PlusCircle className="w-3.5 h-3.5 text-slate-500" />
                  <span>Nieuwe calculatie</span>
                </button>

                <button
                  onClick={() => setShowConfig(!showConfig)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-semibold border transition-colors shadow-2xs ${
                    showConfig
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-300'
                  }`}
                  title="Tarieven en AZT-materiaalconstante aanpassen"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Tarieven / TZ 143</span>
                </button>

                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors shadow-2xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print / PDF</span>
                </button>
              </>
            )}

            {!isStandaloneHtml && (
              <button
                onClick={handleDownloadHtmlApp}
                disabled={isHtmlDownloading}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 transition-colors shadow-2xs disabled:opacity-60"
                title="Download de volledige applicatie als los HTML-bestand voor offline gebruik"
              >
                {isHtmlDownloading ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                ) : (
                  <Download className="w-3.5 h-3.5 text-blue-600" />
                )}
                <span className="hidden lg:inline">{isHtmlDownloading ? 'Bouwen...' : 'Download HTML'}</span>
              </button>
            )}

            <button
              onClick={() => setIsKnowledgeBaseOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 transition-colors shadow-2xs"
              title="Solera Kennisbank richtlijnen over TZ 51 en TZ 143"
            >
              <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden md:inline">Solera Richtlijnen</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="flex md:hidden border-t border-slate-200 bg-slate-50 px-4 py-2 gap-1 text-xs">
          <button
            onClick={() => setMainTab('splitser')}
            className={`flex-1 py-1.5 text-center rounded font-semibold ${
              mainTab === 'splitser' ? 'bg-white text-slate-900 border border-slate-300 shadow-2xs' : 'text-slate-600'
            }`}
          >
            Splitsen
          </button>
          <button
            onClick={() => setMainTab('calculator')}
            className={`flex-1 py-1.5 text-center rounded font-semibold ${
              mainTab === 'calculator' ? 'bg-white text-slate-900 border border-slate-300 shadow-2xs' : 'text-slate-600'
            }`}
          >
            Zelf Rekenen
          </button>
          <button
            onClick={() => setMainTab('naslag')}
            className={`flex-1 py-1.5 text-center rounded font-semibold ${
              mainTab === 'naslag' ? 'bg-white text-slate-900 border border-slate-300 shadow-2xs' : 'text-slate-600'
            }`}
          >
            Naslag AZT
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5">
        {/* VIEW 1: SPLITSER */}
        {mainTab === 'splitser' && (
          <>
            {!data ? (
              /* STATE 1: Geen calculatie geladen -> Clean white business upload & paste */
              <div className="max-w-2xl mx-auto py-8 sm:py-12">
                <div className="text-center mb-6">
                  <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                    Audatex Schadecalculatie Inlezen
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-lg mx-auto">
                    Plak de tekst van een Solera Audatex calculatie of upload een PDF/scan. Het kenteken wordt direct uitgelezen, gekoppeld aan de RDW en voorzien van een indicatieve dagwaarde.
                  </p>
                </div>

                <InputSection
                  onLoadData={handleLoadData}
                  isLoading={isLoading}
                  setIsLoading={setIsLoading}
                  isCompact={false}
                />
              </div>
            ) : (
              /* STATE 2: Calculatie geladen -> Clean White Dashboard */
              <div className="space-y-4">
                {/* Dossier Header Info */}
                <DossierHeader 
                  meta={data.meta} 
                  onUpdateMeta={handleUpdateMeta}
                  onLookupPlate={handleLookupPlate}
                />

                {/* RDW Voertuiggegevens & Indicatieve Dagwaarde Card */}
                {totalen && (
                  <RdwDagwaardeCard
                    rdw={data.rdw}
                    totaalSchadeBruto={totalen.totaal.totaalBruto}
                    kenteken={data.meta.kenteken}
                    onRefreshRdw={handleLookupPlate}
                    isLoading={isRdwLoading}
                  />
                )}

                {/* Config & Rates Drawer (Toggled) */}
                {showConfig && totalen && (
                  <div className="no-print">
                    <SoleraConfig
                      tarieven={data.tarieven}
                      onUpdateTarieven={handleUpdateTarieven}
                      methode={methode}
                      onSelectMethode={setMethode}
                      invoerTekst143={totalen.soleraInfo.invoerTekst143}
                      advies={totalen.soleraInfo.advies}
                    />
                  </div>
                )}

                {/* Executive KPI Cards */}
                {totalen && (
                  <KPICards
                    voorzijde={totalen.voorzijde}
                    achterzijde={totalen.achterzijde}
                    overig={totalen.overig}
                    totaal={totalen.totaal}
                  />
                )}

                {/* Sub View Switcher Tabs */}
                <div className="flex items-center justify-between border-b border-slate-200 pb-2 no-print">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setActiveSubView('report')}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors ${
                        activeSubView === 'report'
                          ? 'bg-white text-slate-900 border border-slate-300 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                      }`}
                    >
                      Financieel Rapport
                    </button>

                    <button
                      onClick={() => setActiveSubView('table')}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors ${
                        activeSubView === 'table'
                          ? 'bg-white text-slate-900 border border-slate-300 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                      }`}
                    >
                      Calculatieposities ({data.regels.length})
                    </button>

                    <button
                      onClick={() => setActiveSubView('aftrek')}
                      className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors ${
                        activeSubView === 'aftrek'
                          ? 'bg-white text-slate-900 border border-slate-300 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                      }`}
                    >
                      Aftrekcheck Meerdere Schades (TZ 143)
                    </button>
                  </div>

                  {totalen && (
                    <div className="text-xs text-slate-600 font-mono hidden sm:block">
                      Totaal schadebedrag: <strong className="text-slate-900 font-bold">{formatEuro(totalen.totaal.totaalBruto)}</strong>
                    </div>
                  )}
                </div>

                {/* Active Sub View Content */}
                {totalen && activeSubView === 'report' && (
                  <FinancieelRapport
                    meta={data.meta}
                    tarieven={data.tarieven}
                    voorzijde={totalen.voorzijde}
                    achterzijde={totalen.achterzijde}
                    overig={totalen.overig}
                    totaal={totalen.totaal}
                    soleraInfo={totalen.soleraInfo}
                    methode={methode}
                    rdw={data.rdw}
                  />
                )}

                {totalen && activeSubView === 'table' && (
                  <CalculatieTabel
                    regels={data.regels}
                    onUpdateRegels={handleUpdateRegels}
                    spuittarief={data.tarieven.spuittarief}
                  />
                )}

                {totalen && activeSubView === 'aftrek' && (
                  <AftrekCalculator
                    initialSchade1={calculatorInitialSchade1}
                    initialSchade2={calculatorInitialSchade2}
                    uurtarief={data.tarieven.spuittarief}
                  />
                )}
              </div>
            )}
          </>
        )}

        {/* VIEW 2: ZELF REKENEN (AFTREKCHECK) */}
        {mainTab === 'calculator' && (
          <div className="max-w-4xl mx-auto py-2">
            <AftrekCalculator
              initialSchade1={calculatorInitialSchade1}
              initialSchade2={calculatorInitialSchade2}
              uurtarief={data?.tarieven.spuittarief || 94.00}
            />
          </div>
        )}

        {/* VIEW 3: NASLAG AZT */}
        {mainTab === 'naslag' && (
          <div className="max-w-5xl mx-auto py-2">
            <AztNaslag />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-3.5 text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="font-medium text-slate-700">Audatex Schade Calculatie Splitter • Solera AZT & RDW Open Data Integratie</span>
          </div>
          <div className="flex flex-wrap items-center gap-2.5 text-slate-500">
            <span>Solera Nederland / Audatex Richtlijnen • 1 AE = 6 min (10 AE = 1 uur)</span>
            <span className="text-slate-300 hidden sm:inline">•</span>
            <span className="font-semibold text-slate-800">Developed by Danny Radjkoemar</span>
          </div>
        </div>
      </footer>

      {/* Solera Knowledge Base Modal */}
      <SoleraInfoModal
        isOpen={isKnowledgeBaseOpen}
        onClose={() => setIsKnowledgeBaseOpen(false)}
      />
    </div>
  );
}
